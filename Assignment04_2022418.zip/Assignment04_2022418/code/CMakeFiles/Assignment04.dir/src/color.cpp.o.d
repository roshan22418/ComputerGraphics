CMakeFiles/Assignment04.dir/src/color.cpp.o: \
 /home/roshan8906/Documents/Computer_graphics/Assignment_All/Final/code/src/color.cpp \
 /usr/include/stdc-predef.h \
 /home/roshan8906/Documents/Computer_graphics/Assignment_All/Final/code/src/color.h
