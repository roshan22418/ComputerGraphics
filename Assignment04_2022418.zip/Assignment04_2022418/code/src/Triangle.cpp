#include <iostream> // For debug output
#include <cmath>
#include "Triangle.h"

// Determinant calculation for a 3x3 matrix
double determinant3x3(double a11, double a12, double a13,
                      double a21, double a22, double a23,
                      double a31, double a32, double a33) {
    return a11 * (a22 * a33 - a23 * a32) -
           a12 * (a21 * a33 - a23 * a31) +
           a13 * (a21 * a32 - a22 * a31);
}

bool Triangle::intersect(Ray& ray) const {
    Vector3D edge1 = v1 - v0;
    Vector3D edge2 = v2 - v0;

    // Set up matrix elements for Cramer's rule
    double a11 = ray.getDirection().X();
    double a12 = edge1.X();
    double a13 = edge2.X();

    double a21 = ray.getDirection().Y();
    double a22 = edge1.Y();
    double a23 = edge2.Y();

    double a31 = ray.getDirection().Z();
    double a32 = edge1.Z();
    double a33 = edge2.Z();

    Vector3D B = v0 - ray.getOrigin();
    double bx = B.X();
    double by = B.Y();
    double bz = B.Z();

    double detA = determinant3x3(a11, a12, a13, a21, a22, a23, a31, a32, a33);
    if (std::fabs(detA) < 0.00000001) {
        std::cout << "Ray parallel to triangle plane.\n";
        return false;
    }

    // Determinants for parameters t, u, and v
    double detAt = determinant3x3(bx, a12, a13, by, a22, a23, bz, a32, a33);
    double detAu = determinant3x3(a11, bx, a13, a21, by, a23, a31, bz, a33);
    double detAv = determinant3x3(a11, a12, bx, a21, a22, by, a31, a32, bz);

    // Calculate t, u, v using Cramer's rule
    double t = detAt / detA;
    double u = detAu / detA;
    double v = detAv / detA;

    // std::cout << "t: " << t << " u: " << u << " v: " << v << std::endl;

    // Check if intersection point is within triangle and in front of the ray
    if (u >= 0 && v >= 0 && u + v <= 1 && t > 0) {
        ray.setParameter(t, this);  // Ensure ray.setParameter is defined in Ray

    
        Vector3D intersectionPoint = ray.getPosition();
        Vector3D normalAtIntersection = getNormal();

        // Set the normal on the ray
        ray.setNormal(normalAtIntersection);

        return true;
    }

    return false;
}

Vector3D Triangle::getNormal() const {
    Vector3D edge1 = v1 - v0;
    Vector3D edge2 = v2 - v0;
    return unitVector(crossProduct(edge1, edge2));
}
