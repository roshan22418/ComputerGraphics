/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

#include "ray.h"

bool Ray::setParameter(const float par, const Object *obj)
{
	if(par < t && par > SMALLEST_DIST)
	{
		hit = true;
		t = par;
		object = obj;
		return true;
	}
	return false;
}







Ray Ray::reflect() const {
    Vector3D reflectionDir = direction - 2 * dotProduct(direction, normal) * normal;
    reflectionDir.normalize();
    Vector3D reflectionOrigin = getPosition() + reflectionDir * SMALLEST_DIST;
    return Ray(reflectionOrigin, reflectionDir, level + 1, refractive_index);
}

Ray Ray::refract(float new_refractive_index, bool& tir) const {
    float eta = refractive_index / new_refractive_index;
    float cos_i = -dotProduct(direction, normal);
    float sin_t2 = eta * eta * (1.0f - cos_i * cos_i);
    if (sin_t2 > 1.0f) {
        tir = true;
		Vector3D l = Vector3D(0,0,0);
        return Ray(l,l); 
    }

    float cos_t = sqrt(1.0f - sin_t2);
    Vector3D refractionDir = eta * direction + (eta * cos_i - cos_t) * normal;
    refractionDir.normalize();

    Vector3D refractionOrigin = getPosition() + refractionDir * SMALLEST_DIST;

    tir = false; 
    return Ray(refractionOrigin, refractionDir, level + 1, new_refractive_index);
}

