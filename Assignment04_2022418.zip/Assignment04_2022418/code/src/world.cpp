/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

#include "world.h"

using namespace std;

float World::firstIntersection(Ray& ray)
{
	for(int i=0; i<objectList.size(); i++)
		objectList[i]->intersect(ray);
	return ray.getParameter();
}

Color World::shade_ray(Ray& ray)
{
	firstIntersection(ray);
	if(ray.didHit())
		return (ray.intersected())->shade(ray);
	return background;
}


Color World::traceRay(const Ray& ray, int depth) {
    if (depth > 5) {
        return background;  
    }

    Ray tempRay = ray;
    firstIntersection(tempRay);

    if (!tempRay.didHit()) {
        return background;
    }








	

    // this part use in question 4 
    
    Color localColor = tempRay.intersected()->shade(tempRay);

    const Material* material = tempRay.intersected()->getMaterial();
    Color reflectionColor(0), refractionColor(0);

    if (material->kr > 0.0) { // Reflective surface
        Ray reflectedRay = tempRay.reflect();
        reflectionColor = traceRay(reflectedRay, depth + 1) * material->kr;
    }
	bool tir = true;
    if (material->kt > 0.0) { // Transparent surface
        Ray refractedRay = tempRay.refract(material->eta, tir);
        refractionColor = traceRay(refractedRay, depth + 1) * material->kt;
    }

    return localColor + reflectionColor + refractionColor;
}

