/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/
#include "world.h"
#include "material.h"
#include "vector3D.h"
#include "sphere.h"

bool Shadow(const World* world, const Vector3D& point, const LightSource* light) {
    Vector3D lightDir = light->getPosition() - point;
    double lightDistance = lightDir.length();
    lightDir.normalize();
    Ray shadowRay(point + lightDir * 1e-4, lightDir);

    // Check if any object blocks the light source
    for (const Object* object : world->getObjectList()) {
        if (object->intersect(shadowRay) && shadowRay.getParameter() < lightDistance) {
            return true; 
        }
    }
    return false;  // No objects blocking, so point is lit
}

// Color Material::shade(const Ray& incidentRay, const bool isSolid) const {
//     // Initialize components
//     Color finalColor(0);
//     Color ambientComponent = ka * color; // Apply ambient light if applicable
//     Color diffuseComponent(0.0);
//     Color specularComponent(0.0);
//     Color refractionColor(0.0);
//     Color reflectionColor(0.0);

//     Vector3D hitPoint = incidentRay.getPosition();
//     Vector3D surfaceNormal = incidentRay.getNormal();

//     // Iterate over each light source to compute lighting contributions
//     for (const auto& lightSource : world->getLights()) {
//         Vector3D lightDir = lightSource->getPosition() - hitPoint;
//         lightDir.normalize();

//         // Shadow check
//         if (Shadow(world, hitPoint, lightSource)) {
//             continue;
//         }

//         // Lambertian reflectance (diffuse component)
//         double lambertian = std::max(0.0, dotProduct(surfaceNormal, lightDir));
//         diffuseComponent = diffuseComponent + (kd * lambertian * color * lightSource->getIntensity());

//         // Phong reflection model (specular component)
//         Vector3D viewDir = incidentRay.getOrigin() - hitPoint;
//         viewDir.normalize();
//         Vector3D halfwayDir = (lightDir + viewDir);
//         halfwayDir.normalize();
//         double phongSpecular = std::pow(std::max(dotProduct(surfaceNormal, halfwayDir), 0.0), n);
//         specularComponent = specularComponent + (ks * phongSpecular * color * lightSource->getIntensity());
//     }

//     Vector3D incidentDir = incidentRay.getDirection();

//     // Reflection calculation
//     if (kr > 0) {
//         Vector3D reflectionDir = incidentDir - 2 * dotProduct(surfaceNormal, incidentDir) * surfaceNormal;
//         Ray reflectionRay(hitPoint + reflectionDir * 0.00000001, reflectionDir); // Offset for self-intersection
//         reflectionColor = kr * world->traceRay(reflectionRay, isSolid);
//     } 
//     else{
//         reflectionColor = 0.0;
//     }

//     // Refraction calculation
//     if (kt > 0) {
//         double cosi = -dotProduct(surfaceNormal, incidentDir);
//         double etaRatio;
//         if (isSolid) {
//             etaRatio = 1 / eta;
//         } 
//         else {
//             etaRatio = eta;
//         }


//         double k = 1 - etaRatio * etaRatio * (1 - cosi * cosi);
//         if (k >= 0) {
//             Vector3D refractionDir = etaRatio * incidentDir + (etaRatio * cosi - sqrt(k)) * surfaceNormal;
//             Ray refractionRay(hitPoint + refractionDir *0.00000001, refractionDir); // Offset for self-intersection
//             refractionColor = kt * world->traceRay(refractionRay, isSolid);
//         }
//     }
//     else{
//         refractionColor = 0.0;
//     }

//     // Combine components to get the final color
//     finalColor = ambientComponent + diffuseComponent + specularComponent + reflectionColor + refractionColor;
//     return finalColor;
//     finalColor = ambientComponent + diffuseComponent + specularComponent;
//     return finalColor;
// }



























Color Material::shade(const Ray& incidentRay, bool isSolid) const {
    // Initialize components
    Color finalColor(0);
    Color ambientComponent = ka * color; // Ambient lighting
    Color diffuseComponent(0.0);
    Color specularComponent(0.0);
    Color refractionColor(0.0);
    Color reflectionColor(0.0);

    

    Vector3D hitPoint = incidentRay.getPosition();
    Vector3D surfaceNormal = incidentRay.getNormal();
    Vector3D incidentDir = incidentRay.getDirection();

    // Iterate over each light source to compute lighting contributions
    for (const auto& lightSource : world->getLights()) {
        Vector3D lightDir = lightSource->getPosition() - hitPoint;
        lightDir.normalize();

        // Shadow check
        if (Shadow(world, hitPoint, lightSource)) {
            continue;
        }

        // Lambertian reflectance (diffuse component)
        double lambertian = std::max(0.0, dotProduct(surfaceNormal, lightDir));
        diffuseComponent = diffuseComponent + (kd * lambertian * color * lightSource->getIntensity());

        // Phong reflection model (specular component)
        Vector3D viewDir = incidentRay.getOrigin() - hitPoint;
        viewDir.normalize();
        Vector3D halfwayDir = (lightDir + viewDir);
        halfwayDir.normalize();
        double phongSpecular = std::pow(std::max(dotProduct(surfaceNormal, halfwayDir), 0.0), n);
        specularComponent = specularComponent + (ks * phongSpecular * color * lightSource->getIntensity());
    }

    // Reflection calculation
    if (kr > 0) {
        Vector3D reflectionDir = incidentDir - 2 * dotProduct(surfaceNormal, incidentDir) * surfaceNormal;
        Ray reflectionRay(hitPoint + reflectionDir * 1e-5, reflectionDir); // Offset for self-intersection
        reflectionColor = kr * world->traceRay(reflectionRay, isSolid);
    }

    // Refraction calculation with Beer's law for absorption
    if (kt > 0) {
        double cosi = -dotProduct(surfaceNormal, incidentDir);
        double etaRatio = isSolid ? 1 / eta : eta;
        double k = 1 - etaRatio * etaRatio * (1 - cosi * cosi);

        if (k >= 0) {
            Vector3D refractionDir = etaRatio * incidentDir + (etaRatio * cosi - sqrt(k)) * surfaceNormal;
            Ray refractionRay(hitPoint + refractionDir * 1e-5, refractionDir); // Offset to prevent self-intersection

            // Trace refraction ray and apply Beer's law
            Color transmissionColor = world->traceRay(refractionRay, isSolid);
            double distance = refractionRay.getParameter();
            Color attenuation = Color(exp(-absorption.r * distance), exp(-absorption.g * distance), exp(-absorption.b * distance));
            refractionColor = kt * transmissionColor * attenuation;
        }
    }

    // Combine all components to get the final color
    finalColor = ambientComponent + diffuseComponent + specularComponent + reflectionColor + refractionColor;
    return finalColor;
}


