#ifndef PLANE_H
#define PLANE_H

#include "object.h"
#include "ray.h"
#include "vector3D.h"
#include "color.h"

class Plane : public Object {
private:
    Vector3D surfaceNormal;  
    Vector3D point;     

public:
    Plane(const Vector3D& _point, const Vector3D& _normal, Material* mat)
        : Object(mat), surfaceNormal(_normal), point(_point) {
        isSolid = true;
    }
    virtual bool intersect(Ray& r) const override;

    virtual Vector3D getNormalAtIntersection(const Vector3D& _point) const {
        return surfaceNormal; 
    }
};

#endif
