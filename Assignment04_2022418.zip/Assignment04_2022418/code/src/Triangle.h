#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "object.h"
#include "vector3D.h"
#include "ray.h"

class Triangle : public Object {
private:
    Vector3D v0;
    Vector3D v1;
    Vector3D v2; 

public:
    Triangle(const Vector3D& _v0, const Vector3D& _v1, const Vector3D& _v2, Material* mat)
        : Object(mat), v0(_v0), v1(_v1), v2(_v2) {
        isSolid = true;
    }

    virtual bool intersect(Ray& ray) const override;
    virtual ~Triangle() = default;

    // Add this line to declare the getNormal() method
    Vector3D getNormal() const;
};

#endif
