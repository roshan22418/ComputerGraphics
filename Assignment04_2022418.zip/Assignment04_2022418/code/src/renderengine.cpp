/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

#include "renderengine.h"

const Color RenderEngine::trace(const int i, const int j)
{
	Vector3D ray_dir = camera->get_ray_direction(i, j);
	Ray ray(camera->get_position(), ray_dir);
	return world->shade_ray(ray);
}

bool RenderEngine::renderLoop()
{
	static int i = 0;
	for(int j = 0; j<camera->getHeight(); j++)
	{
		Color color = trace(i, j);
		color.clamp();
		camera->drawPixel(i, j, color);
	}

	if(++i == camera->getWidth())
	{
		i = 0;
		return true;
	}
	return false;
}





//// part a bonus part
// #include "renderengine.h"
// #include <cmath> // For fabs
// #include <cstdlib> // For rand()

// const Color RenderEngine::trace(const int i, const int j)
// {
// 	Vector3D ray_dir = camera->get_ray_direction(i, j);
// 	Ray ray(camera->get_position(), ray_dir);
// 	return world->shade_ray(ray);
// }

// // Trace a ray with jittered supersampling on edges
// Color RenderEngine::traceRayWithJitteredSupersampling(const Ray& ray, int x, int y) {
//     Color color(0, 0, 0);
//     int sampleCount = 4;  // Number of jittered samples
//     double offset = 0.5;  // Jitter offset range

//     // Detect edge by comparing color with neighboring pixels
//     bool isEdge = detectEdge(x, y);

//     if (isEdge) {
//         for (int i = 0; i < sampleCount; ++i) {
//             double jitterX = (rand() / (double)RAND_MAX - 0.5) * offset;
//             double jitterY = (rand() / (double)RAND_MAX - 0.5) * offset;

//             Ray jitteredRay = camera->getRay(x + jitterX, y + jitterY);
//             color += traceRay(jitteredRay);
//         }
//         color /= sampleCount;
//     } else {
//         color = traceRay(ray);  // No supersampling for non-edges
//     }
//     return color;
// }

// // Edge detection based on color differences with neighboring pixels
// bool RenderEngine::detectEdge(int x, int y) {
//     Color currentColor = getPixelColor(x, y);
//     Color neighborColorX = getPixelColor(x + 1, y);
//     Color neighborColorY = getPixelColor(x, y + 1);
//     double threshold = 0.1;

//     return (fabs(currentColor.r - neighborColorX.r) > threshold ||
//             fabs(currentColor.g - neighborColorY.g) > threshold ||
//             fabs(currentColor.b - neighborColorY.b) > threshold);
// }

// // Helper function for tracing a single ray
// Color RenderEngine::traceRay(const Ray& ray) {
//     return world->shade_ray(ray);
// }

// bool RenderEngine::renderLoop()
// {
// 	static int i = 0;
// 	for (int j = 0; j < camera->getHeight(); j++) {
// 		Vector3D ray_dir = camera->get_ray_direction(i, j);
// 		Ray ray(camera->get_position(), ray_dir);

// 		// Use supersampling on edges, otherwise normal tracing
// 		Color color = traceRayWithJitteredSupersampling(ray, i, j);
// 		color.clamp();
// 		camera->drawPixel(i, j, color);
// 	}

// 	if (++i == camera->getWidth()) {
// 		i = 0;
// 		return true;
// 	}
// 	return false;
// }
