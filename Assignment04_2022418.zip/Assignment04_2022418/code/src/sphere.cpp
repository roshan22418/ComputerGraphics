/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

// sphere.cpp

#include "sphere.h"
#include <cmath> // for std::sqrt and std::max

bool Sphere::intersect(Ray& r) const {
    Vector3D centerVector = r.getOrigin() - position;
    double a = 1.0;
    double b = 2 * dotProduct(r.getDirection(), centerVector);
    double c = dotProduct(centerVector, centerVector) - radius * radius;
    double discriminant = b * b - 4.0 * a * c;

    // Check if the discriminant is non-negative for intersection
    if (discriminant >= 0.0) {
        double t;
        if (discriminant == 0) {
            // One intersection point
            t = -b / (2.0 * a);
            if (r.setParameter(t, this)) {
                Vector3D intersectionPoint = r.getPosition();
                Vector3D normalAtIntersection = getNormal(intersectionPoint);
                r.setNormal(normalAtIntersection);  // Set the normal on the ray
                return true;
            }
        } 
        else {
            // Two intersection points; choose the closer one
            double D = sqrt(discriminant);
            double t1 = (-b - D) / (2.0 * a);
            double t2 = (-b + D) / (2.0 * a);

            // Check if either t1 or t2 are valid and set the parameters
            bool intersect1 = r.setParameter(t1, this);
            bool intersect2 = r.setParameter(t2, this);

            if (intersect1 || intersect2) { 
                // Determine the intersection point based on the parameter set on the ray
                Vector3D intersectionPoint = r.getPosition();
                Vector3D normalAtIntersection = getNormal(intersectionPoint);
                r.setNormal(normalAtIntersection);  // Set the normal on the ray
                return true;
            }
        }
    }
    return false;
}

Vector3D Sphere::getNormal(const Vector3D& point) const {
    // Calculate normal by subtracting point from sphere center and normalizing
    //this is part for question 2
    Vector3D normal = (point - position);
    normal.normalize();
    return normal;
}



// class TransformedSphere : public Sphere {
// public:
//     Matrix4x4 transform;
//     Matrix4x4 inverseTransform;

//     TransformedSphere(const Vector3D& center, double radius, const Matrix4x4& transform)
//         : Sphere(center, radius), transform(transform) {
//         inverseTransform = transform.inverse();
//     }

//     bool intersect(Ray& ray) const override {
//         // Transform the ray to object space
//         Ray transformedRay = ray.transform(inverseTransform);
//         bool hit = Sphere::intersect(transformedRay);

//         if (hit) {
//             // Transform intersection point back to world space
//             ray.setHitPoint(transform * transformedRay.getPosition());
//         }
//         return hit;
//     }
// };
