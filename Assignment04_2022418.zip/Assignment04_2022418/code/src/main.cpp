/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

// Assignment 04: Raytracing

#include "imgui_setup.h"
#include "camera.h"
#include "renderengine.h"
#include "world.h"
#include "material.h"
#include "object.h"
#include "sphere.h"
#include "lightsource.h"
#include "pointlightsource.h"
#include "plane.h"

#include "Triangle.h"

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../depends/stb/stb_image.h"
#include "../depends/stb/stb_image_write.h"

#define RENDER_BATCH_COLUMNS 30 

Camera *camera;
RenderEngine *engine;

int screen_width = 800, screen_height = 600; // This is window size, used to display scaled raytraced image.
int image_width = 1920, image_height = 1080; // This is raytraced image size. Change it if needed.
GLuint texImage;

int main(int, char**)
{
    // Setup window
    GLFWwindow *window = setupWindow(screen_width, screen_height);

    ImVec4 clearColor = ImVec4(1.0f, 1.0f, 1.0f, 1.00f);

    // Setup raytracer camera. This is used to spawn rays.
    Vector3D camera_position(0, 0, 10);
    Vector3D camera_target(0, 0, 0); //Looking down -Z axis
    Vector3D camera_up(0, 1, 0);
    float camera_fovy =  45;
    camera = new Camera(camera_position, camera_target, camera_up, camera_fovy, image_width, image_height);

    //Create a world
    World *world = new World;
    world->setAmbient(Color(1));
    world->setBackground(Color(0.1, 0.3, 0.6));
    
    Material *m = new Material(world);
    m->color = Color(0.1, 0.7, 0.0);
    m->ka = 0.1;
    m->kd = 0.9;
    m->ks = 0.4;   

    Material *dielectricMaterial = new Material(world); 
    dielectricMaterial->color = Color(0.8, 0.8, 1.0);              // Lightly tinted blue color
    dielectricMaterial->ka = 0.05;                                  // Low ambient for subtle light absorption
    dielectricMaterial->kd = 0.05;                                  // Low diffuse, letting the transparency dominate
    dielectricMaterial->ks = 0.2;                                   // Small specular reflection
    dielectricMaterial->kr = 0.05;                                  // Minimal reflectivity (mostly transparent)
    dielectricMaterial->kt = 0.9;                                   // High transparency (mostly transparent)
    dielectricMaterial->eta = 1.33;                                 // Refraction index close to water (1.33)
    dielectricMaterial->n = 64;                                     // Higher shininess for sharper highlights
                     

    
    Object *sphere = new Sphere(Vector3D(2, 4, -10), 3, m);
    world->addObject(sphere);

    




    Material* triangleMaterial = new Material(world);
    triangleMaterial->color = Color(0.1, 0.7, 0.0); // Set triangle color
    triangleMaterial->ka = 0.1; // Ambient reflection coefficient
    triangleMaterial->kd = 0.9; // Diffuse reflection coefficient


     Object *triangle = new Triangle(Vector3D(-4, 2, -4), Vector3D(-5, 2, -4), Vector3D(-4, 2, -3), triangleMaterial);
    world->addObject(triangle);


    LightSource *light = new PointLightSource(world, Vector3D(-19, 10, -6), Color(1, 1, 1));
    world->addLight(light);



    Material* planeMaterial = new Material(world);
    planeMaterial->color = Color(0.4, 0.4, 0.4);
    planeMaterial->ka = 0.5;
    planeMaterial->kd = 0.5;
    planeMaterial->ks = 0.5;
    planeMaterial->kr = 0.9;
    
    Vector3D planePoint(0, -1, 0);        
    Vector3D planeNormal(0, 1, 0);       

    Plane* plane = new Plane(planePoint, planeNormal, planeMaterial);
    world->addObject(plane);

    engine = new RenderEngine(world, camera);

    //Initialise texture
    glGenTextures(1, &texImage);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texImage);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image_width, image_height, 0, GL_RGB, GL_UNSIGNED_BYTE, camera->getBitmap());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        bool render_status;
        for(int i=0; i<RENDER_BATCH_COLUMNS; i++) 
            render_status = engine->renderLoop(); // RenderLoop() raytraces 1 column of pixels at a time.
        if(!render_status)
        {
            // Update texture
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, texImage);
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, image_width, image_height, GL_RGB, GL_UNSIGNED_BYTE, camera->getBitmap());
        } 

        ImGui::Begin("Lumina", NULL, ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::Text("Size: %d x %d", image_width, image_height);
        if(ImGui::Button("Save")){
          char filename[] = "img.png";
          stbi_write_png(filename, image_width, image_height, 3, camera->getBitmap(),0);        
        }
        //Display render view - fit to width
        int win_w, win_h;
        glfwGetWindowSize(window, &win_w, &win_h);
        float image_aspect = (float)image_width/(float)image_height;
        float frac = 0.95; // ensure no horizontal scrolling
        ImGui::Image((void*)(intptr_t)texImage, ImVec2(frac*win_w, frac*win_w/image_aspect), ImVec2(0.0f, 1.0f), ImVec2(1.0f, 0.0f));

        ImGui::End();

        // Rendering
        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clearColor.x, clearColor.y, clearColor.z, clearColor.w);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // Cleanup
    glDeleteTextures(1, &texImage);

    cleanup(window);

    return 0;
}



































// / Material *transparentReflectiveMaterial = new Material(world); 
    // transparentReflectiveMaterial->color = Color(1.0, 1.0, 1.0);    // Pure white for maximum reflectivity
    // transparentReflectiveMaterial->ka = 0.05;                       // Low ambient
    // transparentReflectiveMaterial->kd = 0.0;                        // No diffuse (highly reflective surface)
    // transparentReflectiveMaterial->ks = 1.0;                        // High specular for shininess
    // transparentReflectiveMaterial->kr = 0.9;                        // High reflectivity
    // transparentReflectiveMaterial->kt = 0.8;                        // High transparency (almost transparent)
    // transparentReflectiveMaterial->eta = 1.5;                       // Refraction index of glass (typically around 1.5)
    // transparentReflectiveMaterial->n = 64;                          // Higher shininess exponent for sharp highlights
                          

    // Material *darkReflectiveMaterial = new Material(world); 
    // darkReflectiveMaterial->color = Color(0.1, 0.1, 0.1);          // Dark color
    // darkReflectiveMaterial->ka = 0.1;                               // Moderate ambient
    // darkReflectiveMaterial->kd = 0.1;                               // Low diffuse (dark material absorbs more light)
    // darkReflectiveMaterial->ks = 0.8;                               // High specular, but lower than 1.0
    // darkReflectiveMaterial->kr = 0.6;                               // Reflective, but not as much as a mirror
    // darkReflectiveMaterial->kt = 0.0;                               // Not transparent
    // darkReflectiveMaterial->eta = 1.0;                              // No refraction, as it’s opaque
    // darkReflectiveMaterial->n = 32;                                 // Mid-range shininess for slightly softer highlights
                           

    // Material *halfReflectiveMaterial=new Material(world);
    // halfReflectiveMaterial->color = Color(0.5, 0.5, 0.5);          // Medium gray
    // halfReflectiveMaterial->ka = 0.1;                               // Low ambient, to let reflection/transparency dominate
    // halfReflectiveMaterial->kd = 0.1;                               // Low diffuse for subtle color
    // halfReflectiveMaterial->ks = 0.6;                               // Moderate specular reflection
    // halfReflectiveMaterial->kr = 0.4;                               // Partial reflection
    // halfReflectiveMaterial->kt = 0.6;                               // Partially transparent
    // halfReflectiveMaterial->eta = 1.4;                              // Slightly refractive, for subtle light bending
    // halfReflectiveMaterial->n = 20;                                 // Softer highlights, appropriate for frosted appearance