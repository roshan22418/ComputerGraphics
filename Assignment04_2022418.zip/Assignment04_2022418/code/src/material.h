/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/

//matrial.h
#ifndef _MATERIAL_H_
#define _MATERIAL_H_

#include "color.h"
#include "ray.h"

class World;

class Material
{
private:
    World *world;
public:
    // Material properties
    Color color;
    Color absorption; // Defines how much light each color component absorbs

    double ka;   // Ambient contribution
    double kd;   // Diffuse constant
    double ks;   // Specular constant
    double kr;   // Contribution from reflection
    double kt;   // Contribution from refraction
    double eta;  // Coefficient of refraction
    double n;    // Phong's shininess constant

    // Constructor that initializes all properties, including absorption
    Material(World *w, const Color& color = Color(0), const Color& absorption = Color(0.0, 0.0, 0.0), 
             double ka = 0, double kd = 0.0, double ks = 0, double kr = 0, double kt = 0, double n = 0, double eta = 0) 
        : world(w), color(color), absorption(absorption), ka(ka), kd(kd), ks(ks), kr(kr), kt(kt), n(n), eta(eta) {}

    // Method for shading with Beer's law and other components
    Color shade(const Ray& incident, const bool isSolid) const;
};

#endif

