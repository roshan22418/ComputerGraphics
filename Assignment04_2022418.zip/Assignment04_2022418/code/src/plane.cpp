#include "plane.h"

bool Plane::intersect(Ray& r) const {
    double denom = dotProduct(surfaceNormal, r.getDirection());

    
    if (fabs(denom) < 0.00000001) {
        return false;
    }
    double t = dotProduct(point - r.getOrigin(), surfaceNormal) / denom;
    if (t > 0) {
        
        r.setParameter(t, this);
        r.setNormal(surfaceNormal);
        return true;
    }

    return false;  
}