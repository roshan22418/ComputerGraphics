// Assignment 02: Trandformations, viewing and projection

#include "utils.h"
using namespace std;

int width = 640, height = 640;

void createCubeObject(unsigned int &, unsigned int &);
void setupModelTransformation(unsigned int &);
void setupViewTransformation(unsigned int &);
void setupProjectionTransformation(unsigned int &, int, int);
bool Question_1 = false;
bool Question_2_lookAt = true;
bool Question_2_MylookAt = false;
bool one_point_view = false;
bool two_point_view = false;
bool three_point_bird_view = false;
bool three_point_rat_view = false;

int main(int, char **)
{
    // Setup window
    GLFWwindow *window = setupWindow(width, height);
    ImGuiIO &io = ImGui::GetIO(); // Create IO object

    ImVec4 clearColor = ImVec4(1.0f, 1.0f, 1.0f, 1.00f);

    unsigned int shaderProgram = createProgram("./shaders/vshader.vs", "./shaders/fshader.fs");
    glUseProgram(shaderProgram);

    unsigned int VAO;
    glGenVertexArrays(1, &VAO);

    // setupModelTransformation(shaderProgram);
    // setupViewTransformation(shaderProgram);
    // setupProjectionTransformation(shaderProgram, width, height);

    createCubeObject(shaderProgram, VAO);

    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();
        setupModelTransformation(shaderProgram);
        setupViewTransformation(shaderProgram);
        setupProjectionTransformation(shaderProgram, width, height);

        createCubeObject(shaderProgram, VAO);

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // Add check box to switch the context of view
        ImGui::Begin("View Options");

        if (ImGui::Checkbox("Question 1", &Question_1))
        {
            if (Question_1==true)
            {
                Question_2_lookAt = false;
                Question_2_MylookAt = false;
                one_point_view = false;
                two_point_view = false;
                three_point_bird_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("Question 2 LookAt", &Question_2_lookAt))
        {
            if (Question_2_lookAt==true)
            {
                Question_1 = false;
                Question_2_MylookAt = false;
                one_point_view = false;
                two_point_view = false;
                three_point_bird_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("Question 2 MyLookAt", &Question_2_MylookAt))
        {
            if (Question_2_MylookAt==true)
            {
                Question_1 = false;
                Question_2_lookAt = false;
                one_point_view = false;
                two_point_view = false;
                three_point_bird_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("One Point View", &one_point_view))
        {
            if (one_point_view==true)
            {
                Question_1 = false;
                Question_2_lookAt = false;
                Question_2_MylookAt = false;
                two_point_view = false;
                three_point_bird_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("Two Point View", &two_point_view))
        {
            if (two_point_view==true)
            {
                Question_1 = false;
                Question_2_lookAt = false;
                Question_2_MylookAt = false;
                one_point_view = false;
                three_point_bird_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("Three Point Bird's Eye View", &three_point_bird_view))
        {
            if (three_point_bird_view==true)
            {
                Question_1 = false;
                Question_2_lookAt = false;
                Question_2_MylookAt = false;
                one_point_view = false;
                two_point_view = false;
                three_point_rat_view = false;
            }
        }

        if (ImGui::Checkbox("Three Point Rat's Eye View", &three_point_rat_view))
        {
            if (three_point_rat_view==true)
            {
                Question_1 = false;
                Question_2_lookAt = false;
                Question_2_MylookAt = false;
                one_point_view = false;
                two_point_view = false;
                three_point_bird_view = false;
            }
        }

        ImGui::End();

        glUseProgram(shaderProgram);

        {
            static float f = 0.0f;
            static int counter = 0;

            ImGui::Begin("Information");
            ImGui::Text("%.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
            ImGui::End();
        }

        // Rendering
        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clearColor.x, clearColor.y, clearColor.z, clearColor.w);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glBindVertexArray(VAO);

        glDrawArrays(GL_TRIANGLES, 0, 6 * 2 * 3);

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // Cleanup
    cleanup(window);

    return 0;
}

void createCubeObject(unsigned int &program, unsigned int &cube_VAO)
{
    glUseProgram(program);

    // Bind shader variables
    int vVertex_attrib = glGetAttribLocation(program, "vVertex");
    if (vVertex_attrib == -1)
    {
        fprintf(stderr, "Could not bind location: vVertex\n");
        exit(0);
    }
    int vColor_attrib = glGetAttribLocation(program, "vColor");
    if (vColor_attrib == -1)
    {
        fprintf(stderr, "Could not bind location: vColor\n");
        exit(0);
    }

    // Cube data
    GLfloat cube_vertices[] = {10, 10, 10, -10, 10, 10, -10, -10, 10, 10, -10, 10,      // Front
                               10, 10, -10, -10, 10, -10, -10, -10, -10, 10, -10, -10}; // Back
    GLushort cube_indices[] = {0, 2, 3, 0, 1, 2,                                        // Front
                               4, 7, 6, 4, 6, 5,                                        // Back
                               5, 2, 1, 5, 6, 2,                                        // Left
                               4, 3, 7, 4, 0, 3,                                        // Right
                               1, 0, 4, 1, 4, 5,                                        // Top
                               2, 7, 3, 2, 6, 7};                                       // Bottom
    GLfloat cube_colors[] = {1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1};     // Unique face colors

    // Generate VAO object
    glGenVertexArrays(1, &cube_VAO);
    glBindVertexArray(cube_VAO);

    // Create VBOs for the VAO
    // Position information (data + format)
    int nVertices = 6 * 2 * 3; //(6 faces) * (2 triangles each) * (3 vertices each)
    GLfloat *expanded_vertices = new GLfloat[nVertices * 3];
    for (int i = 0; i < nVertices; i++)
    {
        expanded_vertices[i * 3] = cube_vertices[cube_indices[i] * 3];
        expanded_vertices[i * 3 + 1] = cube_vertices[cube_indices[i] * 3 + 1];
        expanded_vertices[i * 3 + 2] = cube_vertices[cube_indices[i] * 3 + 2];
    }
    GLuint vertex_VBO;
    glGenBuffers(1, &vertex_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, vertex_VBO);
    glBufferData(GL_ARRAY_BUFFER, nVertices * 3 * sizeof(GLfloat), expanded_vertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(vVertex_attrib);
    glVertexAttribPointer(vVertex_attrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
    delete[] expanded_vertices;

    // Color - one for each face
    GLfloat *expanded_colors = new GLfloat[nVertices * 3];
    for (int i = 0; i < nVertices; i++)
    {
        int color_index = i / 6;
        expanded_colors[i * 3] = cube_colors[color_index * 3];
        expanded_colors[i * 3 + 1] = cube_colors[color_index * 3 + 1];
        expanded_colors[i * 3 + 2] = cube_colors[color_index * 3 + 2];
    }
    GLuint color_VBO;
    glGenBuffers(1, &color_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, color_VBO);
    glBufferData(GL_ARRAY_BUFFER, nVertices * 3 * sizeof(GLfloat), expanded_colors, GL_STATIC_DRAW);
    glEnableVertexAttribArray(vColor_attrib);
    glVertexAttribPointer(vColor_attrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
    delete[] expanded_colors;

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0); // Unbind the VAO to disable changes outside this function.
}

// below is printMatrix to check correct or not
void printMatrix(const glm::mat4 &matrix)
{

    for (int i = 0; i < 4; ++i)
    {
        for (int j = 0; j < 4; ++j)
        {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void setupModelTransformation(unsigned int &program)
{
    // Modelling transformations (Model -> World coordinates)
    // comment below line by Roshan
    //  glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, 0.0));//Model coordinates are the world coordinates
    // TODO: Q1 - Apply modelling transformations here.
    glm::vec3 RoationAxis = glm::normalize(glm::vec3(1.0f, 2.0f, 2.0f));
    glm::mat4 model = glm::rotate(glm::mat4(1.0f), glm::radians(30.0f), RoationAxis);
    std::cout << "below is matrix for first quesion " << std::endl;
    printMatrix(model);
    cout << "<---------------------------------->\n";

    // TODO: Reset modelling transformations to Identity. Uncomment line below before attempting Q4!
    if (one_point_view==true|| two_point_view==true ||three_point_bird_view==true||three_point_rat_view==true)
    {
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, 0.0));//Model coordinates are the world coordinates
        
    }
    
    // model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, 0.0));//Model coordinates are the world coordinates

    // Pass on the modelling matrix to the vertex shader
    glUseProgram(program);
    int vModel_uniform = glGetUniformLocation(program, "vModel");
    if (vModel_uniform == -1)
    {
        fprintf(stderr, "Could not bind location: vModel\n");
        exit(0);
    }
    glUniformMatrix4fv(vModel_uniform, 1, GL_FALSE, glm::value_ptr(model));
}

// below 3(a) is required for lookat funcion implement
glm::mat4 myLookAtFunciton(glm::vec3 eye, glm::vec3 center, glm::vec3 up)
{
    glm::vec3 f = glm::normalize(center - eye);
    glm::vec3 s = glm::normalize(glm::cross(f, up));
    glm::vec3 u = glm::cross(s, f);

    // f=∥center−eye∥center−eye​
    // s=∥f×up∥f×up​
    // u=s×f
    float farRightVector = -glm::dot(s, eye);
    float translateAlongUpvector = -glm::dot(u, eye);
    float tranAlFowardView = glm::dot(f, eye);
    // view = ​sx​sy​sz​−s⋅eye ​ux​uy​uz​−u⋅eye​ −fx​−fy​−fz​f⋅eye ​0001​

    glm::mat4 lookatmat = glm::mat4(1.0f); // initilize the identity matrix

    lookatmat[0][0] = s.x;
    lookatmat[1][0] = s.y;
    lookatmat[2][0] = s.z;
    lookatmat[3][0] = farRightVector;
    lookatmat[0][1] = u.x;
    lookatmat[1][1] = u.y;
    lookatmat[2][1] = u.z;
    lookatmat[3][1] = translateAlongUpvector;
    lookatmat[0][2] = -f.x;
    lookatmat[1][2] = -f.y;
    lookatmat[2][2] = -f.z;
    lookatmat[3][2] = tranAlFowardView;

    return lookatmat;
}

void setupViewTransformation(unsigned int &program)
{
    glm::mat4 view;
    glm::vec3 cameraPosition;
    glm::vec3 ObjectPosition_gaze;
    glm::vec3 upVector;
    // Viewing transformations (World -> camera coordinates
    // below code is comminted by roshan
    
    
    
    // camera at (0, 0, 100) looking down the negative Z-axis in a right handed coordinate system

    // TODO: Q3 - Apply viewing transformations here.

    glm::vec3 cameraPosition1 = glm::vec3(50, 100, 20);
    glm::vec3 ObjectPosition_gaze1 = glm::vec3(0, 0, 0);
    glm::vec3 UpVector1 = glm::vec3(0, 0, 1);
    if (Question_1==true)
    {
        view = glm::lookAt(glm::vec3(0.0, 0.0, 100.0), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));        
    }

    else if (Question_2_lookAt)
    {
        // lookAt Function exectue
        view = glm::lookAt(cameraPosition1, ObjectPosition_gaze1, UpVector1);
        cout << "matrix generated by built in funcion LOOkat " << endl;
        printMatrix(view);
        cout << "<----------------------------------------->\n";
    }
    else if (Question_2_MylookAt)
    {
        // mannual LOokat Funtion exectue
        view = myLookAtFunciton(cameraPosition1, ObjectPosition_gaze1, UpVector1);
        cout << "matrix generated by mannual in funcion LOOkat " << endl;
        printMatrix(view);
        cout << "<----------------------------------------->\n";
    }
    // TODO: Q4 - Apply appropriate viewing transformations here to generate 1-point, 2-point, and 3-point perspective views.

    else if(one_point_view) {
        // looking along the Z-axis
        cameraPosition = glm::vec3(15.0, 15.0, 75.0);
        // cameraPosition = glm::vec3(0.0, 12.0, 50.0);
        ObjectPosition_gaze = glm::vec3(0.0, 0.0, 0.0);

        upVector = glm::vec3(0.0, 1.0, 0.0);
        view = myLookAtFunciton(cameraPosition, ObjectPosition_gaze, upVector);
    }
    else if (two_point_view) {
        // looking edge between X and Z or Y or Z
        cameraPosition = glm::vec3(60.0, 0.0, 60.0);
        ObjectPosition_gaze = glm::vec3(0.0, 0.0, 0.0);
        upVector = glm::vec3(0.0, 1.0, 0.0);
        view = myLookAtFunciton(cameraPosition, ObjectPosition_gaze, upVector);
    }
    else if (three_point_bird_view) {
        // look down from above 
        cameraPosition = glm::vec3(30.0, 30.0, 60.0);
        ObjectPosition_gaze = glm::vec3(0.0, 0.0, 0.0);
        upVector = glm::vec3(0.0, 1.0, 0.0); 
        view = myLookAtFunciton(cameraPosition, ObjectPosition_gaze, upVector);
    }
    else if(three_point_rat_view){
        // looking from below for the rat view
        cout<<"enter in THree_point_rat_view"<<endl;
        cameraPosition = glm::vec3(30.0, -30.0, -60.0);
        ObjectPosition_gaze = glm::vec3(0.0, 0.0, 0.0);
        upVector = glm::vec3(0.0, 1.0, 0.0);
        view = myLookAtFunciton(cameraPosition, ObjectPosition_gaze, upVector);
    }

    
    // Pass-on the viewing matrix to the vertex shader
    glUseProgram(program);
    int vView_uniform = glGetUniformLocation(program, "vView");
    if (vView_uniform == -1)
    {
        fprintf(stderr, "Could not bind location: vView\n");
        exit(0);
    }
    glUniformMatrix4fv(vView_uniform, 1, GL_FALSE, glm::value_ptr(view));
}

void setupProjectionTransformation(unsigned int &program, int screen_width, int screen_height)
{
    // Projection transformation
    float aspect = (float)screen_width / (float)screen_height;

    glm::mat4 projection = glm::perspective(45.0f, (GLfloat)screen_width / (GLfloat)screen_height, 0.1f, 1000.0f);

    // Pass on the projection matrix to the vertex shader
    glUseProgram(program);
    int vProjection_uniform = glGetUniformLocation(program, "vProjection");
    if (vProjection_uniform == -1)
    {
        fprintf(stderr, "Could not bind location: vProjection\n");
        exit(0);
    }
    glUniformMatrix4fv(vProjection_uniform, 1, GL_FALSE, glm::value_ptr(projection));
}
