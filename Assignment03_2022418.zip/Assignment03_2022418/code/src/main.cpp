/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/ 

//Assignment 03: Lighting and shading

/*References
  Trackball: http://en.wikibooks.org/wiki/OpenGL_Programming/Modern_OpenGL_Tutorial_Arcball
*/

#include "utils.h"

#define  GLM_FORCE_RADIANS
#define  GLM_ENABLE_EXPERIMENTAL

#include <glm/gtc/type_ptr.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/string_cast.hpp>
float sliderValue = 0.0f;

//Globals
int screen_width = 640, screen_height=640;
GLint vModel_uniform, vView_uniform, vProjection_uniform;
GLint vColor_uniform;
glm::mat4 modelT, viewT, projectionT;        //The model, view and projection transformations

GLint LightColorUniform,LightPositonUniform;

double oldX, oldY, currentX, currentY;
bool isDragging=false;

size_t createSphereObject(unsigned int &, unsigned int &);

void setupModelTransformation(unsigned int &);
void setupViewTransformation(unsigned int &);
void setupProjectionTransformation(unsigned int &);
glm::vec3 getTrackBallVector(double x, double y);

int main(int, char**)
{
    // Setup window
    GLFWwindow *window = setupWindow(screen_width, screen_height);
    ImGuiIO& io = ImGui::GetIO(); // Create IO object

    ImVec4 clearColor = ImVec4(1.0f, 1.0f, 1.0f, 1.00f);



//change here location to change 
unsigned int shaderProgram = createProgram("./shaders/vshader.vs", "./shaders/fshader.fs");

    //Get handle to color variable in shader
    vColor_uniform = glGetUniformLocation(shaderProgram, "vColor");
    if(vColor_uniform == -1){
        fprintf(stderr, "Could not bind location: vColor\n");
        // exit(0);
    }

    LightPositonUniform = glGetUniformLocation(shaderProgram, "lightpos");
    LightColorUniform = glGetUniformLocation(shaderProgram, "lightcolor");
    if(LightPositonUniform== -1 || LightColorUniform== -1){
        
        if (LightColorUniform==-1)
        {
            fprintf(stderr, "Could not bind location: lightcolor unifrom\n");
            // exit(0);
        }
        else
        {
            fprintf(stderr, "Could not bind location: lightposition\n");
            // exit(0);            
        }    
        
        
    }



    glUseProgram(shaderProgram);

    unsigned int VAO;
    glGenVertexArrays(1, &VAO);

    setupModelTransformation(shaderProgram);
    setupViewTransformation(shaderProgram);
    setupProjectionTransformation(shaderProgram);

    size_t IBO_nelems = createSphereObject(shaderProgram, VAO);
		fprintf(stderr, "Size of IBO %lu\n", IBO_nelems);



        // // Light properties
        // glm::vec3 lightPos(30.0f, 30.0f, 30.0f);    // Light position
        // glm::vec3 lightColor(1.0f, 1.0f, 1.0f);     // White light color

        // // Camera position
        // glm::vec3 cameraPos(0.0f, 0.0f, 40.0f);   




        // Get uniform locations for light position, light color, and camera position
        GLint lightPosUniform = glGetUniformLocation(shaderProgram, "lightPos");
        GLint lightColorUniform = glGetUniformLocation(shaderProgram, "lightColor");
        GLint cameraPosUniform = glGetUniformLocation(shaderProgram, "cameraPos");

        //use in all question in 2
        glm::vec3 lightPos(50.0f, 50.0f, 50.0f);    // Light position
        glm::vec3 lightColor(1.0f, 1.0f, 1.0f);     // White light color
        //after 2a use camerapos
        glm::vec3 cameraPos(0.0f, 0.0f, 50.0f);     // Camera position


        // Add uniform locations for spotlight
        GLint spotLightPosUniform = glGetUniformLocation(shaderProgram, "spotLightPos");
        GLint spotLightDirUniform = glGetUniformLocation(shaderProgram, "spotLightDir");
        GLint spotLightCutoffUniform = glGetUniformLocation(shaderProgram, "spotLightCutoff");
        GLint spotLightOuterCutoffUniform = glGetUniformLocation(shaderProgram, "spotLightOuterCutoff");


        // Spotlight properties use in question 3a and 3b
        glm::vec3 spotLightPos(50.0f, 50.0f, 50.0f);    // Position of spotlight
        glm::vec3 spotLightDir(-1.0f, -1.0f, -1.0f);    // Direction of spotlight
        float spotLightCutoff = glm::cos(glm::radians(4.0f)); // Cutoff angle of 20 degrees
        float spotLightOuterCutoff = glm::cos(glm::radians(7.0f));  // Outer cutoff angle 5 degrees larger or more till 10 

        // Inside the render loop
        glUniform3fv(spotLightPosUniform, 1, glm::value_ptr(spotLightPos));
        glUniform3fv(spotLightDirUniform, 1, glm::value_ptr(spotLightDir)); 
        glUniform1f(spotLightCutoffUniform, spotLightCutoff);
        glUniform1f(spotLightOuterCutoffUniform, spotLightOuterCutoff);

    
    



    oldX = oldY = currentX = currentY = 0.0;
    int prevLeftButtonState = GLFW_RELEASE;

    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        // Get current mouse position
        int leftButtonState = glfwGetMouseButton(window,GLFW_MOUSE_BUTTON_LEFT);
        double x,y;
        glfwGetCursorPos(window,&x,&y);
        if(leftButtonState == GLFW_PRESS && prevLeftButtonState == GLFW_RELEASE){
            isDragging = true;
            currentX = oldX = x;
            currentY = oldY = y;
        }
        else if(leftButtonState == GLFW_PRESS && prevLeftButtonState == GLFW_PRESS){
            currentX = x;
            currentY = y;
        }
        else if(leftButtonState == GLFW_RELEASE && prevLeftButtonState == GLFW_PRESS){
            isDragging = false;
        }

        // Rotate based on mouse drag movement
        prevLeftButtonState = leftButtonState;
        if(isDragging && (currentX !=oldX || currentY != oldY))
        {
            glm::vec3 va = getTrackBallVector(oldX, oldY);
            glm::vec3 vb = getTrackBallVector(currentX, currentY);

            float angle = acos(std::min(1.0f, glm::dot(va,vb)));
            glm::vec3 axis_in_camera_coord = glm::cross(va, vb);
            glm::mat3 camera2object = glm::inverse(glm::mat3(viewT*modelT));
            glm::vec3 axis_in_object_coord = camera2object * axis_in_camera_coord;
            modelT = glm::rotate(modelT, angle, axis_in_object_coord);
            glUniformMatrix4fv(vModel_uniform, 1, GL_FALSE, glm::value_ptr(modelT));

            oldX = currentX;
            oldY = currentY;
        }

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        glUseProgram(shaderProgram);


        //bonus part 
// //         cameraPos = glm::vec3(0.0f, 0.0f, 50.0f);
// //         // Spotlight properties (headlight is tied to camera)
//         glm::vec3 headlightPos = cameraPos;
//         glm::vec3 headlightDir = glm::normalize(-glm::vec3(viewT[2]));
// // The direction of the headlight is the forward direction of the camera
//          glUniform3fv(spotLightPosUniform, 1, glm::value_ptr(headlightPos));
//         glUniform3fv(spotLightDirUniform, 1, glm::value_ptr(headlightDir));
//         glUniform1f(spotLightCutoffUniform, spotLightCutoff);
//         glUniform1f(spotLightOuterCutoffUniform, spotLightOuterCutoff);


        // //Question Q2 -> a 
        // Pass light and camera data to the shader
        
        
        glUniform3fv(lightPosUniform, 1, glm::value_ptr(lightPos));
        glUniform3fv(lightColorUniform, 1, glm::value_ptr(lightColor));
        glUniform3fv(cameraPosUniform, 1, glm::value_ptr(cameraPos));





        {
            ImGui::Begin("Information");                          
            ImGui::Text("%.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
            ImGui::End();
        }

        // Rendering
        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clearColor.x, clearColor.y, clearColor.z, clearColor.w);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glBindVertexArray(VAO); 
        


        glUniform3f(vColor_uniform, 0.6, 0.6, 0.6);
        glUniform3f(LightColorUniform, 1, 1, 1);
        glUniform3f(LightPositonUniform, 50, 50, 50);


				glDrawElements(GL_TRIANGLES, IBO_nelems, GL_UNSIGNED_SHORT, 0);

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);

    }

    // Cleanup
    cleanup(window);

    return 0;
}

size_t createSphereObject(unsigned int &program, unsigned int &sphere_VAO)
{
    glUseProgram(program);

    // Bind shader variables
    int vVertex_attrib = glGetAttribLocation(program, "vVertex");
    if(vVertex_attrib == -1) {
        fprintf(stderr, "Could not bind location: vVertex\n");
        exit(0);
    }


    // Question 1
    int vNormal_attrib = glGetAttribLocation(program, "vNormal");
    if (vNormal_attrib == -1) {
        fprintf(stderr, "Could not bind location: vNormal\n");
        exit(0);
    }


		//Sphere data: use spherical parameterization to produce points
		//(x,y,z) = (r sin th cos ph, t sin th sin ph, r cos th), th \in [0, pi], ph \in [0, 2 pi]
		//Generate vertices and normals (TODO).
#define DELTA_ANGLE 18
		int nTheta = 180/DELTA_ANGLE + 1;
		int nPhi = 360/DELTA_ANGLE + 1;
		GLfloat *sphere_vertices = new GLfloat[nTheta*nPhi*3];

        
        // Question 1
        GLfloat *sphere_normals = new GLfloat[nTheta * nPhi * 3];


		float theta, phi, x, y, z;
		float radius = 10.0f;
		for (int j = 0; j<nTheta; j++)
			for(int i=0; i<nPhi; i++)
			{
				theta = float(j*DELTA_ANGLE)*M_PI/180.0;
				phi = float(i*DELTA_ANGLE)*M_PI/180.0;
				x = sinf(theta)*cosf(phi);
				y = sinf(theta)*sinf(phi);
				z = cos(theta);
				sphere_vertices[(i + j*nPhi)*3 + 0] = radius*x; 
                sphere_vertices[(i + j*nPhi)*3 + 1] = radius*y;
                sphere_vertices[(i + j*nPhi)*3 + 2] = radius*z; 


                // Question 1
                sphere_normals[(i+j*nPhi)*3+0] = x;
                sphere_normals[(i+j*nPhi)*3+1] = y;
                sphere_normals[(i+j*nPhi)*3+2] = z;

			}

		//Generate index array
		GLushort *sphere_indices = new GLushort[2*(nTheta-1)*(nPhi-1)*3];
		for(int j=0; j<(nTheta-1); j++)
			for(int i=0; i<(nPhi-1); i++)
			{
				//Upper triangle
				sphere_indices[(i + j*(nPhi-1))*6 + 0] = i + j*nPhi;
				sphere_indices[(i + j*(nPhi-1))*6 + 1] = i + (j+1)*nPhi;
				sphere_indices[(i + j*(nPhi-1))*6 + 2] = i + 1 + j*nPhi;

				//Lower triangle
				sphere_indices[(i + j*(nPhi-1))*6 + 3] = i + 1 + j*nPhi;
				sphere_indices[(i + j*(nPhi-1))*6 + 4] = i + (j+1)*nPhi;
				sphere_indices[(i + j*(nPhi-1))*6 + 5] = i + 1 + (j+1)*nPhi;
		}

    //Generate VAO object
    glGenVertexArrays(1, &sphere_VAO);
    glBindVertexArray(sphere_VAO);

    //Create VBO/IBO for the VAO
    GLuint vertex_VBO;
    glGenBuffers(1, &vertex_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, vertex_VBO);

		glBufferData(GL_ARRAY_BUFFER, nTheta*nPhi*3*sizeof(GLfloat), sphere_vertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(vVertex_attrib);
    glVertexAttribPointer(vVertex_attrib, 3, GL_FLOAT, GL_FALSE, 0, 0);
    delete []sphere_vertices;

    // Question 1
    GLuint normal_vbo;
    glGenBuffers(1,&normal_vbo);
    glBindBuffer(GL_ARRAY_BUFFER,normal_vbo);
    glBufferData(GL_ARRAY_BUFFER,nTheta*nPhi*3*sizeof(GLfloat),sphere_normals,GL_STATIC_DRAW);
    glEnableVertexAttribArray(vNormal_attrib);
    glVertexAttribPointer(vNormal_attrib,3,GL_FLOAT,GL_FALSE,0,0);
    // GLushort *sphere_indices = new GLushort[2 * (nTheta - 1) * (nPhi - 1) * 3];


		GLuint indices_IBO;
		glGenBuffers(1, &indices_IBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indices_IBO);
		size_t IBO_nelems = (nTheta-1)*(nPhi-1)*6; //Number of elements in the IBO
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, IBO_nelems*sizeof(GLushort), sphere_indices, GL_STATIC_DRAW);
		delete []sphere_indices;


        // Question 1
        delete[] sphere_normals;

		glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0); //Unbind the VAO to disable changes outside this function.

		return IBO_nelems;
}




void setupModelTransformation(unsigned int &program)
{
    //Modelling transformations (Model -> World coordinates)
    modelT = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, 0.0));//Model coordinates are the world coordinates

    //Pass on the modelling matrix to the vertex shader
    glUseProgram(program);
    vModel_uniform = glGetUniformLocation(program, "vModel");
    if(vModel_uniform == -1){
        fprintf(stderr, "Could not bind location: vModel\n");
        exit(0);
    }
    glUniformMatrix4fv(vModel_uniform, 1, GL_FALSE, glm::value_ptr(modelT));
}


void setupViewTransformation(unsigned int &program)
{
    //Viewing transformations (World -> Camera coordinates
    //Camera at (0, 0, 100) looking down the negative Z-axis in a right handed coordinate system
    viewT = glm::lookAt(glm::vec3(40.0, -40.0, 40.0), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));

    //Pass-on the viewing matrix to the vertex shader
    glUseProgram(program);
    vView_uniform = glGetUniformLocation(program, "vView");
    if(vView_uniform == -1){
        fprintf(stderr, "Could not bind location: vView\n");
        exit(0);
    }
    glUniformMatrix4fv(vView_uniform, 1, GL_FALSE, glm::value_ptr(viewT));
}

void setupProjectionTransformation(unsigned int &program)
{
    //Projection transformation
    projectionT = glm::perspective(45.0f, (GLfloat)screen_width/(GLfloat)screen_height, 0.1f, 1000.0f);

    //Pass on the projection matrix to the vertex shader
    glUseProgram(program);
    vProjection_uniform = glGetUniformLocation(program, "vProjection");
    if(vProjection_uniform == -1){
        fprintf(stderr, "Could not bind location: vProjection\n");
        exit(0);
    }
    glUniformMatrix4fv(vProjection_uniform, 1, GL_FALSE, glm::value_ptr(projectionT));
}

glm::vec3 getTrackBallVector(double x, double y)
{
	glm::vec3 p = glm::vec3(2.0*x/screen_width - 1.0, 2.0*y/screen_height - 1.0, 0.0); //Normalize to [-1, +1]
	p.y = -p.y; //Invert Y since screen coordinate and OpenGL coordinates have different Y directions.

	float mag2 = p.x*p.x + p.y*p.y;
	if(mag2 <= 1.0f)
		p.z = sqrtf(1.0f - mag2);
	else
		p = glm::normalize(p); //Nearest point, close to the sides of the trackball
	return p;
}



