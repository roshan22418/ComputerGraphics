#version 330 core

in vec3 fragPos;  
in vec3 normal;   

uniform vec3 vColor;        
uniform vec3 lightColor;    
uniform vec3 cameraPos;    
uniform vec3 spotLightPos; 
uniform vec3 spotLightDir;     
uniform float spotLightCutoff;

out vec4 outColor;

vec3 calculateSpotLight(vec3 normal, vec3 fragPos, vec3 viewDir) {
    vec3 lightDir = normalize(spotLightPos - fragPos);

    float theta = dot(lightDir, normalize(-spotLightDir));

    if (theta > spotLightCutoff) {
        // Ambient lighting
        float ambientStrength = 0.5;
        vec3 ambient = ambientStrength * lightColor;

        // Diffuse lighting
        float diff = max(dot(normal, lightDir), 0.0);
        vec3 diffuse = diff * lightColor;

        // Specular lighting
        float specularStrength = 0.5;
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
        vec3 specular = specularStrength * spec * lightColor;

        // Combine lighting components
        return (ambient + diffuse + specular) * vColor;
    }

    else{
        return vec3(0.0);
    }
    
}

void main() {
    vec3 viewDir = normalize(cameraPos - fragPos);       // View direction (camera to fragment)

    vec3 lighting = calculateSpotLight(normalize(normal), fragPos, viewDir);

    outColor = vec4(lighting, 1.0);
}
