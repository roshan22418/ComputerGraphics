#version 330 core

in vec3 vVertex; 
in vec3 vNormal; 

uniform mat4 vModel;      
uniform mat4 vView;      
uniform mat4 vProjection; 
//this is the color of the object 
uniform vec3 vColor;   

//this is about where is my point light in workd space 
uniform vec3 lightPos; 
//this is about what is the color of the point light   
uniform vec3 lightColor; 
// this is about where is why camera position in which world space position i see my object  
uniform vec3 cameraPos;    


out vec3 fColor;  

void main() {
    // Transform the vertex position into world space and this part do all question in 2 because object seen in world space 
    
    vec4 worldPos = vModel * vec4(vVertex, 1.0);
    vec3 fragPos = vec3(worldPos);  // Convert from vec4 to vec3 due all thing is vec3 like vcolor and all thing 

    // Transform the normal to world space
    vec3 normal = normalize(mat3(transpose(inverse(vModel))) * vNormal);

    // Ambient component
    float ambientStrength = 0.5;
    vec3 ambient = ambientStrength * lightColor;

    // Diffuse component
    vec3 lightDir = normalize(lightPos - fragPos);
    float diff = max(dot(normal, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // Specular component
    float specularStrength = 0.5;
    vec3 viewDir = normalize(cameraPos - fragPos);
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = max(pow(dot(viewDir, reflectDir), 32), 0.0);  // Phong exponent = 32
    vec3 specular = specularStrength * spec * lightColor;

    vec3 lighting = ambient + diffuse + specular;

    // Multiply by the object color
    fColor = lighting * vColor;

    gl_Position = vProjection * vView * worldPos;
}
