#version 330 core

in vec3 fColor;  // Color passed from vertex shader
out vec4 outColor;

void main(void) {
    outColor = vec4(fColor, 1.0);  // Output the final color with full opacity
}
