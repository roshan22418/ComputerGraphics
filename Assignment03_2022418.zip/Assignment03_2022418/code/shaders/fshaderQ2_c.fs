#version 330 core

in vec3 fragPos;  
in vec3 normal;  

uniform vec3 lightPos;   
uniform vec3 lightColor;  
uniform vec3 cameraPos;   
uniform vec3 vColor;     
out vec4 outColor;       
void main() {

    vec3 norm = normalize(normal);

    vec3 lightDir = normalize(lightPos - fragPos);

    // Ambient component
    float ambientStrength = 0.2;
    // vec3 ambientStrength = vec3(1.0, 1.0, 1.0);
    vec3 ambient = ambientStrength * lightColor;

    // Diffuse component
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    float specularStrength = 0.5;
    // vec3 specularStrength = vec3(1.0, 1.0, 1.0);
    vec3 viewDir = normalize(cameraPos - fragPos);
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = max(pow(dot(viewDir, reflectDir), 32.0), 0.0);
    vec3 specular = specularStrength * spec * lightColor;

    vec3 lighting = ambient + diffuse + specular;

    vec3 finalColor = lighting * vColor;

  
    outColor = vec4(finalColor, 1.0);
}
