#version 330 core

in vec3 vVertex;
in vec3 vNormal; 

uniform mat4 vModel;
uniform mat4 vView;
uniform mat4 vProjection;
uniform vec3 vColor;  
uniform vec3 lightpos;  

out vec3 fColor;   
out vec3 fnormal;  
out vec3 fragPos; 

void main() {
    // Transform vertex position to world space and then to clip space( the space in which points exist just before they undergo normalization)
	gl_Position = vProjection * vView * vModel * vec4(vVertex, 1.0);
	
    // Pass fragment position and normal to the fragment shader
     // Calculate fragment position in world space
	fragPos = vec3(vModel * vec4(vVertex, 1.0));
    
	fnormal = normalize(mat3(transpose(inverse(vModel))) * vNormal); 
    
    // pass fragment shader
    fColor = vColor;
}
