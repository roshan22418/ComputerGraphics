#version 330 core

in vec3 vVertex;
in vec3 vNormal;

uniform mat4 vModel;
uniform mat4 vView;
uniform mat4 vProjection;

out vec3 fragPos;  
out vec3 normal;   

void main() {
    // Transform vertex position to world space
    vec4 worldPos = vModel * vec4(vVertex, 1.0);
    fragPos = vec3(worldPos);

    // Pass transformed normal
    normal = mat3(transpose(inverse(vModel))) * vNormal;

    gl_Position = vProjection * vView * worldPos;
}
