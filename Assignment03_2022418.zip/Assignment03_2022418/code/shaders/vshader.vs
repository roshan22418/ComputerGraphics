#version 330 core

in vec3 vVertex;  
in vec3 vNormal;  // Normal at the vertex (added)

uniform mat4 vModel;
uniform mat4 vView;
uniform mat4 vProjection;
uniform vec3 vColor;

out vec3 fColor;  // Output color to the fragment shader
out vec3 fragNormal;  // Output the normal to the fragment shader (added)

void main() {
    // Transform the vertex position into clip space ( the space in which points exist just before they undergo normalization)
	gl_Position = vProjection * vView * vModel * vec4(vVertex, 1.0);

    // Pass the color directly there is no chage here change in fshader
	fColor = vColor;

    // Pass the normal (in object space) to the fragment shader
    fragNormal = vNormal;
}
