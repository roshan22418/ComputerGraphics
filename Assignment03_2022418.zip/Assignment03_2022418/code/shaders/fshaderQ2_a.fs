
#version 330 core

in vec3 fColor;   
in vec3 fnormal; 
in vec3 fragPos;  

uniform vec3 lightpos;   
uniform vec3 lightcolor; 

out vec4 fragColor;

void main() {
    
    vec3 norm = normalize(fnormal);
    
  
    vec3 lightDir = normalize(lightpos - fragPos);
    
    // Calculate the diffuse factor using the dot product of the normal and light direction
    float diff = max(dot(norm, lightDir), 0.0);
    
    // Combine the light color with the object color, scaled by the diffuse factor (no specular component)
    vec3 diffuse = diff * lightcolor * fColor;
    fragColor = vec4(diffuse, 1.0);
}