#version 330 core

in vec3 fragPos;  
in vec3 normal;  

uniform vec3 vColor;       
uniform vec3 lightColor;      
uniform vec3 cameraPos;      
uniform vec3 spotLightPos;  
uniform vec3 spotLightDir;   
uniform float spotLightCutoff; 
uniform float spotLightOuterCutoff;

out vec4 outColor;


vec3 calculateLighting(vec3 normal, vec3 lightDir, vec3 viewDir) {
   
    float ambientStrength = 0.2;
    vec3 ambient = ambientStrength * lightColor;

   
    float diff = max(dot(normal, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    
    float specularStrength = 0.5;
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
    vec3 specular = specularStrength * spec * lightColor;

    return ambient + diffuse + specular;
}


vec3 calculateSpotLight(vec3 normal, vec3 fragPos, vec3 viewDir) {
    vec3 lightDir = normalize(spotLightPos - fragPos);
    float theta = dot(lightDir, normalize(-spotLightDir));


    if (theta > spotLightOuterCutoff) {
        vec3 lighting = calculateLighting(normal, lightDir, viewDir);

        if (theta > spotLightCutoff) {
            return lighting * vColor;
        }
        else {
            // Calculate intensity: smoothly transition from inner cone to outer cone
        // float epsilon = spotLightCutoff - spotLightOuterCutoff;
        // float intensity = clamp((theta - spotLightOuterCutoff) / epsilon, 0.0, 1.0);
    
            float intensity = (theta - spotLightOuterCutoff) / (spotLightCutoff - spotLightOuterCutoff);
            intensity = clamp(intensity, 0.0, 1.0);
            return lighting * vColor * intensity;
        }
    }

    
    return vec3(0.0);
}

void main() {
    
    vec3 viewDir = normalize(cameraPos - fragPos);

    
    vec3 lighting = calculateSpotLight(normalize(normal), fragPos, viewDir);

    
    outColor = vec4(lighting, 1.0);
}