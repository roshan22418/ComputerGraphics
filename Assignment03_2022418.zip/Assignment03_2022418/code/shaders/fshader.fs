#version 330 core

in vec3 fColor;      
in vec3 fragNormal;  
out vec4 outColor;

void main(void) {
    //upcoming normal vector normalize as the intructed in question
    vec3 normal1 = normalize(fragNormal);
    //here [-1,-1] to [0,1]
    vec3 normalColor = (normal1 +1.0)*0.5; 
    // Combine the normal-based color and the passed color
    vec3 finalColor = fColor * normalColor;

    // fragment with alpha is 1.0 fully opaque
    outColor = vec4(finalColor, 1.0);
}
