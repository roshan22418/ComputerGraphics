/******************************************************************************
 *                                                                            *
 *  Copyright (c) 2023 Ojaswa Sharma. All rights reserved.                    *
 *                                                                            *
 *  Author: Ojaswa Sharma                                                     *
 *  E-mail: ojaswa@iiitd.ac.in                                                *
 *                                                                            *
 *  This code is provided solely for the purpose of the CSE 333/533 course    *
 *  at IIIT Delhi. Unauthorized reproduction, distribution, or disclosure     *
 *  of this code, in whole or in part, without the prior written consent of   *
 *  the author is strictly prohibited.                                        *
 *                                                                            *
 *  This code is provided "as is", without warranty of any kind, express      *
 *  or implied, including but not limited to the warranties of                *
 *  merchantability, fitness for a particular purpose, and noninfringement.   *
 *                                                                            *
 ******************************************************************************/ 

#include "utils.h"

#define DRAW_QUADRATIC_BEZIER 1 // Use to switch Linear and quadratic bezier curves
#define SAMPLES_PER_BEZIER 10 //Sample each Bezier curve as N=10 segments and draw as connected lines

// GLobal variables
std::vector<float> controlPoints;
std::vector<float> linearBezier;
std::vector<float> quadraticBezier;
int width = 640, height = 640; 
bool controlPointsUpdated = false;
bool controlPointsFinished = false;
int selectedControlPoint = -1;

void calculatePiecewiseLinearBezier()
{
    // Since linearBezier is just a polyline, we can just copy the control points and plot.
    // However to show how a piecewise parametric curve needs to be plotted, we sample t and 
    // evaluate all linear bezier curves.
    // linearBezier.assign(controlPoints.begin(), controlPoints.end());

    linearBezier.clear();
    int sz  = controlPoints.size(); // Contains 3 points/vertex. Ignore Z
    float x[2], y[2];
    float delta_t = 1.0/(SAMPLES_PER_BEZIER - 1.0);
    float t;
    for(int i=0; i<(sz-3); i+=3) {
        x[0] = controlPoints[i];
        y[0] = controlPoints[i+1];
        x[1] = controlPoints[i+3];
        y[1] = controlPoints[i+4];
        linearBezier.push_back(x[0]);
        linearBezier.push_back(y[0]);
        linearBezier.push_back(0.0);
        t = 0.0;
        for (float j=1; j<(SAMPLES_PER_BEZIER-1); j++)
        {
        t += delta_t;
        linearBezier.push_back(x[0] + t*(x[1] - x[0]));
        linearBezier.push_back(y[0] + t*(y[1] - y[0]));
        linearBezier.push_back(0.0);
        }
        // No need to add the last point for this segment, since it will be added as first point in next.
    }
    // However, add last point of entire piecewise curve here (i.e, the last control point)
    linearBezier.push_back(x[1]);
    linearBezier.push_back(y[1]);
    linearBezier.push_back(0.0);
}

void calculatePiecewiseQuadraticBezier()
{
    // TODO complete 
    quadraticBezier.clear();
    int sizeofControl = controlPoints.size();
    float x[3], y[3];
    float Small_t = 1.0f / (SAMPLES_PER_BEZIER - 1.0f);
    float t;
    //if two point or less than two point return 
    if (sizeofControl < 6) {
        return;
    }
    // Iterate over control points and step will be 6
    for (int i = 0; i < (sizeofControl - 6); i += 6) {
        // Load P0, P1, and P2
        x[0] = controlPoints[i];      //x0
        y[0] = controlPoints[i + 1];  //y0
        controlPoints[i+2] = 0;       //z0   manually reset_Z = 0
        x[1] = controlPoints[i + 3];  //x1
        y[1] = controlPoints[i + 4];  //y1
        controlPoints[i+5] = 0;       //z1   manually reset_Z = 0
        x[2] = controlPoints[i + 6];  //x2
        y[2] = controlPoints[i + 7];  //y2
        controlPoints[i+8] = 0;       //z2   manually reset_Z = 0

        // start point insert into quadratic bezier curve and intilize the t is 0
        t = 0.0f;
        quadraticBezier.push_back(x[0]); // Start point p0(x0,y0,z0)
        quadraticBezier.push_back(y[0]);
        quadraticBezier.push_back(0.0f);
        for (int j = 1; j < (SAMPLES_PER_BEZIER - 1); j++) {
            t += Small_t;

            // Linear interpolation between P0 and P1, and P1 and P2
            float q0_x = x[0] + t * (x[1] - x[0]);
            float q0_y = y[0] + t * (y[1] - y[0]);
            float q1_x = x[1] + t * (x[2] - x[1]);
            float q1_y = y[1] + t * (y[2] - y[1]);
            // Compute the quadratic Bézier point by linear combination(interpolation) by q0,q1 and after that insert into data structure
            float bezier_x = q0_x + t * (q1_x - q0_x);
            float bezier_y = q0_y + t * (q1_y - q0_y);

            quadraticBezier.push_back(bezier_x);
            quadraticBezier.push_back(bezier_y);
            quadraticBezier.push_back(0.0f); // z-coordinate
        }
        
        // C1 Continuity Adjustment: Ensure the next curve starts with a matching tangent
        if (i + 8 < sizeofControl) {
            // Ensure that the tangent at P2 of the current curve matches the tangent at P0' of the next curve
            float next_p0_x = controlPoints[i + 6];  // P2 becomes become  P0 for next quadratic bezier curve 
           
            float next_p0_y = controlPoints[i + 7];
            
            // Reflect P1 over P2 to maintain the same tangent that help to G1 continutiy to provide so need to be 
            //calcualte the tangent
            float tangent_x = x[2] - x[1];  // Tangent vector from P1 to P2 for x corrdinate
            float tangent_y = y[2] - y[1];  // Tangent vector from P1 to P2 for y corrdinate
            
            // Set P1 for next quadratic bezier curve p1'(say) for the next curve such that the tangent continues smoothly
            //that help to G1 continuity
            controlPoints[i + 9] = next_p0_x + tangent_x;

            controlPoints[i + 10] = next_p0_y + tangent_y;
        }
    }
    // Add the last point of the curve p2(x2,y2,0) and insert into data structure like linear bezier curve 
    quadraticBezier.push_back(x[2]);
    quadraticBezier.push_back(y[2]);
    quadraticBezier.push_back(0.0f);

}

int main(int, char* argv[])
{
    GLFWwindow* window = setupWindow(width, height);
    ImGuiIO& io = ImGui::GetIO(); // Create IO object

    ImVec4 clear_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

    unsigned int shaderProgram = createProgram("./shaders/vshader.vs", "./shaders/fshader.fs");
	glUseProgram(shaderProgram);

    // Create VBOs, VAOs
    unsigned int VBO_controlPoints, VBO_linearBezier, VBO_quadraticBezier;
    unsigned int VAO_controlPoints, VAO_linearBezier, VAO_quadraticBezier;
    glGenBuffers(1, &VBO_controlPoints);
    glGenVertexArrays(1, &VAO_controlPoints);
    glGenBuffers(1, &VBO_linearBezier);
    glGenVertexArrays(1, &VAO_linearBezier);
    glGenBuffers(1, &VBO_quadraticBezier);
    glGenVertexArrays(1, &VAO_quadraticBezier);
    //add quadratic beizercurve vao

    int button_status = 0;

    //Display loop
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // Rendering
        showOptionsDialog(controlPoints, io);
        ImGui::Render();

        // Add a new point on mouse click
        float x,y ;
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);


				if(!ImGui::IsAnyItemActive()) {
					if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
						x = io.MousePos.x;
						y = io.MousePos.y;
						if(!controlPointsFinished) { // Add points
							addControlPoint(controlPoints, x, y, width, height);
							controlPointsUpdated = true;
						} else { // Select point
							searchNearestControlPoint(x, y);
						} 
					}
					
					if(ImGui::IsMouseDragging(ImGuiMouseButton_Left) && controlPointsFinished) { // Edit points
						if(selectedControlPoint >=0) {
							x = io.MousePos.x;
							y = io.MousePos.y;
							editControlPoint(controlPoints, x, y, width, height);
							controlPointsUpdated = true;
						}
					}
					
					if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)) { // Stop adding points
						controlPointsFinished = true;
					}
				}

        if(controlPointsUpdated) {
            // Update VAO/VBO for control points (since we added a new point)
            glBindVertexArray(VAO_controlPoints);
            glBindBuffer(GL_ARRAY_BUFFER, VBO_controlPoints);
            glBufferData(GL_ARRAY_BUFFER, controlPoints.size()*sizeof(GLfloat), &controlPoints[0], GL_DYNAMIC_DRAW);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
            glEnableVertexAttribArray(0); //Enable first attribute buffer (vertices)

            // Update VAO/VBO for piecewise linear Bezier curve (since we added a new point)
            calculatePiecewiseLinearBezier();
            glBindVertexArray(VAO_linearBezier);
            glBindBuffer(GL_ARRAY_BUFFER, VBO_linearBezier);
            glBufferData(GL_ARRAY_BUFFER, linearBezier.size()*sizeof(GLfloat), &linearBezier[0], GL_DYNAMIC_DRAW);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
            glEnableVertexAttribArray(0); //Enable first attribute buffer (vertices)

            // Update VAO/VBO for piecewise quadratic Bezier curve
            // TODO Complete:

            calculatePiecewiseQuadraticBezier();
            glBindVertexArray(VAO_quadraticBezier);
            glBindBuffer(GL_ARRAY_BUFFER, VBO_quadraticBezier);
            glBufferData(GL_ARRAY_BUFFER, quadraticBezier.size() * sizeof(GLfloat), &quadraticBezier[0], GL_DYNAMIC_DRAW);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
            glEnableVertexAttribArray(0); // Enable first attribute buffer (vertices)
        
            controlPointsUpdated = false; // Finish all VAO/VBO updates before setting this to false.
        }

        glUseProgram(shaderProgram);

        // Draw control points
        glBindVertexArray(VAO_controlPoints);
				glDrawArrays(GL_POINTS, 0, controlPoints.size()/3); // Draw points

#if DRAW_QUADRATIC_BEZIER
        glBindVertexArray(VAO_quadraticBezier);
        glDrawArrays(GL_LINE_STRIP, 0, quadraticBezier.size() / 3);
#else
        // Draw linear Bezier
        glBindVertexArray(VAO_linearBezier);
        glDrawArrays(GL_LINE_STRIP, 0, linearBezier.size()/3); //Draw lines
#endif

        glUseProgram(0);

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(window);

    }

    // Delete VBO buffers
    glDeleteBuffers(1, &VBO_controlPoints);
    glDeleteBuffers(1, &VBO_linearBezier);
    glDeleteBuffers(1, &VBO_quadraticBezier);
    //TODO:

    // Cleanup
    cleanup(window);
    return 0;
}
