#include <math.h>
#include <helper.h>

int sign(float f)
{
    if (f >= 0)
    {
        return 1;
    }
    else
    {
        return -1;
    }
}

float distance(float x1, float x2, float y1, float y2)
{
    float dist = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    return dist;
}
