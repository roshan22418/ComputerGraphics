#include <vector>
#include <iostream>
#include <bits/stdc++.h>
#include <string>
#include <helper.h>
#include <cmath>
#include <cstdlib>
#include <ctime>

struct Point
{
    float x, y;
    float r, g, b;
    float size;

    bool operator==(const Point &other) const
    {
        return x == other.x && y == other.y &&
               r == other.r && g == other.g && b == other.b &&
               size == other.size;
    }

    Point copy(float x_offset, float y_offset)
    {
        Point p = {x + x_offset, y + y_offset, r, g, b, size};
        return p;
    }
};

class Entity
{

    int search_entity_index(int id, std::vector<Entity> &entities)
    {
        for (int i = 0; i < entities.size(); i++)
        {
            if (entities[i].id == id)
            {
                return i;
            }
        }
        return -1;
    }
    bool operator==(const Entity &other) const
    {
        return id == other.id;
    }

public:
    int id;
    float centerX, centerY;
    float velocity;
    float alive_for = 0;
    float lifetime = 0;
    std::vector<std::vector<int>> point_inds = {{}};
    std::vector<Entity *> connections;

    void del(std::vector<std::vector<Point>> &frames, int currentFrame)
    {

        auto &currentFramePoints = frames[currentFrame];
        currentFramePoints.erase(
            std::remove_if(currentFramePoints.begin(), currentFramePoints.end(),
                           [this, currentFrame, &currentFramePoints](const Point &p)
                           {
                               int index = &p - &currentFramePoints[0];
                               return std::find(point_inds[currentFrame].begin(), point_inds[currentFrame].end(), index) != point_inds[currentFrame].end();
                           }),
            currentFramePoints.end());
    }

    Entity copy(std::vector<std::vector<Point>> &frames, int currentFrame, int x_offset, int y_offset)
    {
        Entity temp = *this; // Copy all properties of the current entity
        temp.point_inds[currentFrame].clear();

        // Copy each point with an offset
        for (auto &i : point_inds[currentFrame])
        {
            Point *p = &frames[currentFrame][i];
            Point p1 = p->copy(x_offset, y_offset);
            temp.point_inds[currentFrame].push_back(frames[currentFrame].size());
            frames[currentFrame].push_back(p1);
        }
        temp.centerX += x_offset;
        temp.centerY += y_offset;

        return temp;
    }

    void move_to(float x, float y, int currentFrame, std::vector<std::vector<Point>> &frames)
    {
        float xoff = x - centerX;
        float yoff = y - centerY;
        // printf("moving");
        for (auto &i : point_inds[currentFrame])
        {
            Point *p = &frames[currentFrame][i];
            p->y += yoff;
            p->x += xoff;
        }
        centerX = x;
        centerY = y;
    }
};

std::pair<float, float> get_center_inds(std::vector<int> &point_inds, std::vector<std::vector<Point>> &frames, int currentFrame)
{

    float centerX = 0.0f, centerY = 0.0f;
    for (auto &i : point_inds)
    {
        Point *point = &frames[currentFrame][i];
        centerX += point->x;
        centerY += point->y;
    }
    centerX /= point_inds.size();
    centerY /= point_inds.size();
    return std::make_pair(centerX, centerY);
}

void update_entity_center_inds(Entity *e, std::vector<std::vector<Point>> &frames, int currentFrame)
{
    if (e != NULL)
    {
        std::pair<float, float> center = get_center_inds(e->point_inds[currentFrame], frames, currentFrame);
        e->centerX = center.first;
        e->centerY = center.second;
    }
}

void select_entity(std::vector<int> &selectedPoints, int currentFrame, Entity *e1)
{
    if (e1 != NULL)
    {
        selectedPoints.insert(selectedPoints.end(), e1->point_inds[currentFrame].begin(), e1->point_inds[currentFrame].end());
    }
}

Entity make_emitter_entity(std::vector<int> &indeces, std::vector<std::vector<Point>> &frames, int currentFrame, int &entity_id)
{
    Entity temp;
    if (indeces.empty())
    {
        temp.id = -1;
        return temp;
    }
    temp.id = entity_id;
    entity_id++;
    temp.velocity = 0;
    for (auto &i : indeces)
    {
        temp.point_inds[currentFrame].push_back(i);
    }
    update_entity_center_inds(&temp, frames, currentFrame);

    return temp;
}

class Nodetype
{
public:
    std::vector<Nodetype *> connections = {};
    std::vector<Entity> entities = {};
    float centerX, centerY;
    int type = 0;
    std::string name = (char *)malloc(100 * sizeof(char));

    bool operator==(const Nodetype &other) const
    {
        return name == other.name;
    }

    bool connected_to(Nodetype *e)
    {
        for (auto &e1 : connections)
        {
            if (e == e1)
            {
                return true;
            }
        }
        return false;
    }

    void connect(Nodetype *e)
    {
        if (e != this)
        {
            connections.push_back(e);
        }
    }

    void disconnect(Nodetype *e)
    {
        for (int i = 0; i < connections.size(); i++)
        {
            if (e == connections[i])
            {
                connections.erase(connections.begin() + i);
            }
        }
    }

    void update_center(std::vector<std::vector<Point>> &frames, int currentFrame)
    {
        float cx = 0, cy = 0;
        for (auto &e : entities)
        {
            update_entity_center_inds(&e, frames, currentFrame);
            cx += e.centerX;
            cy += e.centerY;
        }
        centerX = cx / entities.size();
        centerY = cy / entities.size();
    }
    void del(std::vector<std::vector<Point>> &frames, int currentFrame)
    {
        for (auto &e : entities)
        {
            e.del(frames, currentFrame);
        }
        entities.clear();
    }
};

class Object : public Nodetype
{
public:
};

class Emitter : public Nodetype
{
public:
    void addstroke(std::vector<int> &inds, int currentFrame, std::vector<std::vector<Point>> &frames, int &freeid)
    {
        Entity e1 = make_emitter_entity(inds, frames, currentFrame, freeid);
        if (e1.id != -1)
        {
            e1.velocity = 1;
            e1.lifetime = 1;
            entities.push_back(e1);
        }
        inds.clear();
        update_center(frames, currentFrame);
    }

    void start(float deltatime, int currentFrame, std::vector<std::vector<Point>> &frames, int &counter)
    {
        // Iterate through existing entities in the emitter
        for (auto &e : entities)
        {
            float newX = e.centerX + e.velocity * deltatime;
            float newY = e.centerY + e.velocity * deltatime;

            e.move_to(newX, newY, currentFrame, frames);
        }
    }
};

class Oscillator : public Nodetype
{
public:
    std::vector<float> phases = {};
    void addstroke(std::vector<int> &inds, int currentFrame, std::vector<std::vector<Point>> &frames, int &freeid)
    {
        Entity e1 = make_emitter_entity(inds, frames, currentFrame, freeid);
        if (e1.id != -1)
        {
            e1.velocity = 2;
            e1.lifetime = 1;
            entities.push_back(e1);
            float randomps = static_cast<float>(rand()) / RAND_MAX * 2.0f * M_PI;
            phases.push_back(randomps);
        }
        inds.clear();
        update_center(frames, currentFrame);
    }

    void start(float deltatime, int currentFrame, std::vector<std::vector<Point>> &frames, int &counter, float oscillationAmplitude, float oscillationFrequency, float oscillationAngle)
    {
        float frequency = oscillationFrequency;
        float amplitude = oscillationAmplitude;
        static bool seeded = false;
        if (!seeded)
        {
            srand((unsigned int)time(nullptr));
            seeded = true;
        }

        for (int i = 0; i < entities.size(); i++)
        {
            Entity e = entities[i];
            printf("oscilator\n");

            float time = (float)counter / 60.0f;
            float oscillationFactor = amplitude * sin((2.0f * M_PI * frequency * time) + phases[i]);

            float newX = e.centerX + oscillationFactor * cos(oscillationAngle);
            float newY = e.centerY + oscillationFactor * sin(oscillationAngle);

            e.move_to(newX, newY, currentFrame, frames);
            e.alive_for += deltatime;

            printf("Time: %f, Oscillation: %f, PhaseShift: %f\n", time, oscillationFactor, phases[i]);
        }
    }
};

Nodetype *find_closest_node_to(float x, float y, float radius, std::vector<Nodetype> &nodes)
{
    for (auto &e : nodes)
    {
        if (distance(x, e.centerX, y, e.centerY) <= radius)
        {
            return &e;
        }
    }
    return NULL;
}

Nodetype *search_node(char *name, std::vector<Nodetype> &nodes)
{
    for (auto &e : nodes)
    {
        if (e.name == name)
        {
            return &e;
        }
    }
    return NULL;
}

void select_node(char *name, std::vector<Nodetype> &nodes, std::vector<int> &selectedPoints, int currentFrame, Nodetype *selc)
{
    Nodetype *n = search_node(name, nodes);
    if (n == NULL)
    {
        return;
    }
    else
    {
        selectedPoints.clear();
        for (auto &e : n->entities)
        {
            select_entity(selectedPoints, currentFrame, &e);
        }
        selc = n;
    }
}

void make_object(char *name, std::vector<Nodetype> &nodes, std::vector<int> &selectedPointinds, std::vector<std::vector<Point>> &frames, int currentFrame, int &freeid)
{

    Nodetype *n = search_node(name, nodes);
    if (n == NULL)
    {
        Object temp;
        Entity e1 = make_emitter_entity(selectedPointinds, frames, currentFrame, freeid);
        temp.entities.push_back(e1);
        temp.centerX = e1.centerX;
        temp.centerY = e1.centerY;
        temp.name = name;
        nodes.push_back(temp);
    }
    else
    {
        n->entities.clear();
        Entity e1 = make_emitter_entity(selectedPointinds, frames, currentFrame, freeid);
        freeid++;
        n->entities.push_back(e1);
        n->centerX = e1.centerX;
        n->centerY = e1.centerY;
        n->name = name;
    }
}