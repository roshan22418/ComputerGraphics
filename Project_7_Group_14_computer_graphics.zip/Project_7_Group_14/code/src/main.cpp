#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <vector>
#include <stdio.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <helper.h>
#include <datatypes.h>



std::vector<Point> thisframe;
std::vector<std::vector<Point>> frames;
std::vector<int> emmitbuffer;
std::vector<int> oscillatebuffer;
std::vector<Nodetype> nodes = {};
std::vector<int> selectedPointinds;
std::vector<Point> lassoPoints; // Points defining the lasso boundary
std::vector<Point> graph_mode_points;
std::vector<Nodetype *> temp_connected_nodes;
std::vector<Emitter> emitters;
std::vector<Oscillator> oscillators;
Nodetype *selected_node = NULL;
char *node_name = (char *)malloc(100 * sizeof(char));
int freeid = 0;
int currentFrame = 0;
bool isDrawing = false;
bool isNewStroke = false;
bool isEraser = false;
bool isSelecting = false; // Flag for selection mode
bool isBrushMode = true;  // Flag for brush mode (default enabled)
bool isPlaying = false;
bool isDrawingEntity = false;
bool istransforming = false;
bool points_scaled = false;
bool graph_mode = false;
bool isEmmitingmode = false;
bool isOscillatingmode = false;
bool emittion_start = false;
bool oscillation_start = false;
int emmitbufferind = 0;
int oscillatebfferind = 0;
float brushSize = 3.0f;
float colorR = 0.0f, colorG = 0.0f, colorB = 0.0f;
int gapfac = 3;
float gapThreshold = brushSize / gapfac;
float cursorX = 0.0f, cursorY = 0.0f;
float cursor_speedX = 0.0f, cursor_speedY = 0.0f;
float cursorX_last_pressed = 0.0f, cursorY_last_pressed = 0.0f;
float cumulative_scale = 1.0f;
float finaldist = 0;
float initaldist = 0;

float playSpeed = 1.0f;
double lastFrameTime = 0.0;

int counter = 0;

float oscillationAmplitude = 0.2f; // Default amplitude
float oscillationFrequency = 1.0f; // Default frequency
float oscillationAngle = 0.0f;     // Default angle in degrees
float color_offset = 0;

int graph_points_length = 0;

bool showMove = false;
bool showScale = false;
bool showRotate = false;



void init_frame()
{
    int N = (int)1e6;
    thisframe.reserve(N);
    frames.push_back(thisframe);
    thisframe.reserve(1000000);            // Reserve space for 1,000,000 Point objects
    frames.reserve(1000);                  // Reserve space for 1,000 vectors of Point
    emmitbuffer.reserve(1000000);          // Reserve space for 1,000,000 Point pointers
    nodes.reserve(1000000);                // Reserve space for 1,000,000 Nodetype objects
    selectedPointinds.reserve(1000000);    // Reserve space for 1,000,000 Point pointers
    lassoPoints.reserve(1000000);          // Reserve space for 1,000,000 Point objects
    graph_mode_points.reserve(1000000);    // Reserve space for 1,000,000 Point objects
    temp_connected_nodes.reserve(1000000); // Reserve space for 1,000,000 Nodetype pointers
    emitters.reserve(10000);
}

void drawCircle(float cx, float cy, float r, float red, float green, float blue)
{
    glBegin(GL_TRIANGLE_FAN);
    glColor3f(red, green, blue);
    glVertex2f(cx, cy);
    int numSegments = 20;
    for (int i = 0; i <= numSegments; ++i)
    {
        float angle = 2.0f * M_PI * float(i) / float(numSegments);
        float dx = r * cosf(angle);
        float dy = r * sinf(angle);
        glVertex2f(cx + dx, cy + dy);
    }
    glEnd();
}



void drawCursorCircle(float cx, float cy, float r)
{
    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINE_LOOP);
    int numSegments = 20;
    for (int i = 0; i <= numSegments; ++i)
    {
        float angle = 2.0f * M_PI * float(i) / float(numSegments);
        float dx = r * cosf(angle);
        float dy = r * sinf(angle);
        glVertex2f(cx + dx, cy + dy);
    }
    glEnd();
}



void drawDottedLine(const std::vector<Point> &points)
{
    glColor3f(1.0f, 1.0f, 0.0f);
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(1, 0xAAAA); // Dotted pattern
    glBegin(GL_LINE_LOOP);
    for (const auto &point : points)
    {
        glVertex2f(point.x, point.y);
    }
    glEnd();
    glDisable(GL_LINE_STIPPLE);
}


void clear_selection()
{
    selectedPointinds.clear();
    selected_node = NULL;
}


void deleteSelectedPoints()
{
    auto &currentFramePoints = frames[currentFrame];
    currentFramePoints.erase(
        std::remove_if(currentFramePoints.begin(), currentFramePoints.end(),
                       [&currentFramePoints](const Point &p)
                       {
                           int index = &p - &currentFramePoints[0];
                           return std::find(selectedPointinds.begin(), selectedPointinds.end(), index) != selectedPointinds.end();
                       }),
        currentFramePoints.end());

    selectedPointinds.clear();
}



bool isPointInPolygon(const Point &p, const std::vector<Point> &poly)
{
    int count = 0;
    for (size_t i = 0, j = poly.size() - 1; i < poly.size(); j = i++)
    {
        const auto &pi = poly[i];
        const auto &pj = poly[j];
        if (((pi.y > p.y) != (pj.y > p.y)) &&
            (p.x < (pj.x - pi.x) * (p.y - pi.y) / (pj.y - pi.y) + pi.x))
        {
            count++;
        }
    }
    return (count % 2) == 1;
}



void fillGap(Point *p1, Point *p2, std::vector<Point> &arr)
{
    float dist = distance(p1->x, p2->x, p1->y, p2->y);
    int numCircles = static_cast<int>(dist / gapThreshold);

    for (int i = 1; i < numCircles; ++i)
    {
        float t = static_cast<float>(i) / numCircles;
        float interpX = p1->x + t * (p2->x - p1->x);
        float interpY = p1->y + t * (p2->y - p1->y);
        (arr).push_back({interpX, interpY, p1->r, p1->g, p1->b, p1->size});
    }
}



void draw(Point *newpoint, std::vector<Point> *arr, bool newstroke)
{

    if (!(*arr).empty() && !newstroke)
    {
        fillGap(&(*arr).back(), newpoint, *arr);
    }

    (*arr).push_back(*newpoint);
}


void draw_entity(Entity *e, float curx, float cury, std::vector<Point> *arr)
{
    float x_offset = (e->centerX) - curx;
    float y_offset = (e->centerY) - cury;
    for (auto i : selectedPointinds)
    {
        Point *p = &frames[currentFrame][i];
        Point newpoint = {p->x - x_offset, p->y - y_offset, p->r, p->g, p->b, p->size};
        (*arr).push_back(newpoint);
    }
}

void drawline(float x1, float y1, float x2, float y2, std::vector<Point> &arr, float thickness)
{
    Point p1 = {x1, y1, 1, 0, 0, thickness};
    Point p2 = {x2, y2, 1, 0, 0, thickness};
    arr.push_back(p1);
    arr.push_back(p2);
    fillGap(&p1, &p2, arr);
}

void applyTransformations()
{
    istransforming = true;
    if (showMove)
    {
        if (isDrawing)
        {
            for (auto i : selectedPointinds)
            {
                Point *point = &frames[currentFrame][i];
                point->x += cursor_speedX;
                point->y += cursor_speedY;
            }
            if (selected_node != NULL)
            {
                selected_node->update_center(frames, currentFrame);
            }
        }
    }
    if (showScale)
    {

        auto center = get_center_inds(selectedPointinds, frames, currentFrame);
        float centerX = center.first;
        float centerY = center.second;

        float sp = distance(0, cursor_speedX, 0, cursor_speedY);

        float scale_direction = sign(cursor_speedX);

        float scale_factor = 1 + 0.01 * scale_direction * sp;

        if (isDrawing)
        {
            for (auto i : selectedPointinds)
            {
                Point *point = &frames[currentFrame][i];
                point->x = centerX + (point->x - centerX) * scale_factor;
                point->y = centerY + (point->y - centerY) * scale_factor;
                point->size = point->size * scale_factor;
            }
        }
    }

    if (showRotate)
    {
        float angle = cursor_speedX * M_PI / 180.0f; // Convert to radians
        auto center = get_center_inds(selectedPointinds, frames, currentFrame);
        float centerX = center.first;
        float centerY = center.second;

        if (isDrawing)
        {
            for (auto i : selectedPointinds)
            {
                Point *point = &frames[currentFrame][i];
                float dx = point->x - centerX;
                float dy = point->y - centerY;
                point->x = centerX + (dx * cos(angle) - dy * sin(angle));
                point->y = centerY + (dx * sin(angle) + dy * cos(angle));
            }
        }
    }
}

void render()
{
    glClear(GL_COLOR_BUFFER_BIT);

    counter++;

    if (!graph_mode)
    {
        color_offset = 0;
    }

    if (emittion_start)
    {

        for (auto e : emitters)
        {
            e.start(0.1, currentFrame, frames, counter);
        }
        for (auto e : oscillators)
        {
            e.start(0.1, currentFrame, frames, counter, oscillationAmplitude, oscillationFrequency, oscillationAngle);
        }
    }

    // Draw all points in the current frame
    for (const auto &point : frames[currentFrame])
    {
        drawCircle(point.x, point.y, point.size / 2.0f, point.r + color_offset, point.g + color_offset, point.b + color_offset);
    }

    // Draw selected points with a different color
    for (auto i : selectedPointinds)
    {
        Point *point = &frames[currentFrame][i];
        drawCircle(point->x, point->y, point->size / 2.0f, 1.0f, 0.0f, 0.0f);
    }

    if (graph_mode)
    {
        color_offset = 0.5;

        for (auto &n : nodes)
        {
            drawCircle(n.centerX, n.centerY, 20, 0, 1, 0);
        }
        for (const auto &point : graph_mode_points)
        {
            drawCircle(point.x, point.y, point.size / 2.0f, point.r, point.g, point.b);
        }
    }

    // Draw the lasso (dotted line)
    if (!lassoPoints.empty())
    {
        drawDottedLine(lassoPoints);
    }

    if (!isPlaying)
    {
        drawCursorCircle(cursorX, cursorY, brushSize / 2.0f);
    }

    glFlush();
}

// Function to advance frames in animation playback
void updateAnimation()
{
    double currentTime = glfwGetTime();
    if (currentTime - lastFrameTime >= (1.0 / playSpeed))
    {
        currentFrame = (currentFrame + 1) % frames.size();
        lastFrameTime = currentTime;
    }
}

// ImGui menu for selection and transformations
void renderImGuiMenu()
{

    ImGui::Begin("Toolbox");

    ImGui::InputText("Enter Text", node_name, 100 * sizeof(char));

    ImGui::Text("You entered: %s", node_name);

    if (ImGui::Checkbox("Brush Mode", &isBrushMode))
    {
        if (isBrushMode)
            isSelecting = false;
    }
    if (ImGui::Checkbox("Select Tool", &isSelecting))
    {
        if (isSelecting)
            isBrushMode = false;
    }
    if (ImGui::Checkbox("Emitting texture", &isEmmitingmode))
    {
        Emitter e;
        emitters.push_back(e);
    }
    if (ImGui::Checkbox("Oscillating texture", &isOscillatingmode))
    {
        Oscillator o;
        oscillators.push_back(o);
    }

    if (isOscillatingmode)
    {
        ImGui::SliderFloat("Amplitude", &oscillationAmplitude, 0.1f, 10.0f, "%.2f");
        ImGui::SliderFloat("Frequency", &oscillationFrequency, 0.1f, 5.0f, "%.2f");
        ImGui::SliderFloat("Angle of Oscillation", &oscillationAngle, -3.14f, 3.14f, "%.1f");
    }

    ImGui::Checkbox("start movement", &emittion_start);

    ImGui::SliderFloat("Brush Size", &brushSize, 1.0f, 20.0f);
    ImGui::ColorEdit3("Brush Color", &colorR);
    ImGui::Checkbox("Entity Brush", &isDrawingEntity);
    ImGui::Checkbox("Eraser", &isEraser);
    ImGui::Checkbox("Graph Mode", &graph_mode);
    if (graph_mode)
    {
        clear_selection();
        isSelecting = false;
        isBrushMode = true;
    }

    if (isSelecting)
    {

        if (ImGui::Button("make object"))
        {
            make_object(node_name, nodes, selectedPointinds, frames, currentFrame, freeid);
        }

        if (ImGui::Button("select object"))
        {
            select_node(node_name, nodes, selectedPointinds, currentFrame, selected_node);
        }
        if (ImGui::Button("delete object"))
        {
            Nodetype *n = search_node(node_name, nodes);
            if (n != NULL)
            {
                n->del(frames, currentFrame);
            }
        }

        if (ImGui::Button("Clear Selection"))
        {
            clear_selection();
            lassoPoints.clear();
            selected_node = NULL;
        }

        if (ImGui::Button("Delete Selection"))
        {
            deleteSelectedPoints();
        }

        ImGui::Checkbox("Move Selected", &showMove);
        ImGui::Checkbox("Scale Selected", &showScale);
        ImGui::Checkbox("Rotate Selected", &showRotate);

        if (showMove || showScale || showRotate)
        {
            applyTransformations();
        }
    }

    if (ImGui::Button("Clear Frame"))
    {
        frames[currentFrame].clear();
        selectedPointinds.clear();
        nodes.clear();
        graph_mode_points.clear();
        
    }

    if (ImGui::Button("Add New Frame"))
    {
        isOscillatingmode = false;
        isEmmitingmode = false;
        emittion_start = false;
        frames.push_back(frames[currentFrame]);
        for (auto &n : nodes)
        {
            for (auto &e : n.entities)
            {
                e.point_inds.push_back({});
                for (auto &point : frames[currentFrame + 1])
                {
                    for (auto &i : e.point_inds[currentFrame])
                    {
                        if ((frames[currentFrame][i]) == point)
                        {
                            e.point_inds[currentFrame + 1].push_back(i);
                        }
                    }
                }
            }
        }
        for (auto &n : emitters)
        {
            for (auto &e : n.entities)
            {
                e.point_inds.push_back({});
                for (auto &point : frames[currentFrame + 1])
                {
                    for (auto &i : e.point_inds[currentFrame])
                    {
                        if ((frames[currentFrame][i]) == point)
                        {
                            e.point_inds[currentFrame + 1].push_back(i);
                        }
                    }
                }
            }
        }
        for (auto &n : oscillators)
        {
            for (auto &e : n.entities)
            {
                e.point_inds.push_back({});
                for (auto &point : frames[currentFrame + 1])
                {
                    for (auto &i : e.point_inds[currentFrame])
                    {
                        if ((frames[currentFrame][i]) == point)
                        {
                            e.point_inds[currentFrame + 1].push_back(i);
                        }
                    }
                }
            }
        }

        currentFrame = frames.size() - 1;
    }

    if (ImGui::Button("Next Frame") && currentFrame < frames.size() - 1)
    {
        currentFrame++;
    }
    if (ImGui::Button("Previous Frame") && currentFrame > 0)
    {
        currentFrame--;
    }

    ImGui::Text("Current Frame: %d / %li", currentFrame + 1, frames.size());

    if (ImGui::Button("Play Animation"))
    {
        isPlaying = true;
        lastFrameTime = glfwGetTime();
    }
    if (ImGui::Button("Stop Animation"))
    {
        isPlaying = false;
        currentFrame = 0;
    }

    ImGui::SliderFloat("Animation Speed", &playSpeed, 0.1f, 10.0f);

    ImGui::End();
}

void cursor_pos_speed_handler(GLFWwindow *window)
{

    int windowHeight;
    glfwGetWindowSize(window, nullptr, &windowHeight);
    float old_cur_x = cursorX;
    float old_cur_y = cursorY;

    double cx;
    double cy;

    glfwGetCursorPos(window, &cx, &cy);

    cursorX = (float)cx;
    cursorY = (float)(windowHeight - cy);

    cursor_speedX = cursorX - old_cur_x;
    cursor_speedY = cursorY - old_cur_y;
}

// Cursor position callback
void cursor_position_callback(GLFWwindow *window, double xpos, double ypos)
{
    int windowHeight;
    glfwGetWindowSize(window, nullptr, &windowHeight);

    float tempcursorX = static_cast<float>(xpos);
    float tempcursorY = static_cast<float>(windowHeight - ypos);

    if (isBrushMode && isDrawing)
    {
        clear_selection();
        float r = isEraser ? 1.0f : colorR;

        float g = isEraser ? 1.0f : colorG;
        float b = isEraser ? 1.0f : colorB;

        Point newPoint = {tempcursorX, tempcursorY, r, g, b, brushSize};

        if (graph_mode)
        {
            draw(&newPoint, &graph_mode_points, isNewStroke);
        }
        else
        {
            draw(&newPoint, &frames[currentFrame], isNewStroke);
        }

        isNewStroke = false;
    }
    else if ((isSelecting && isDrawing) && (!istransforming))
    {
        lassoPoints.push_back({tempcursorX, tempcursorY, 0, 0, 0, 1});
    }
}

void clear_transformations()
{
    if (showMove)
    {
        showMove = false;
    }
    if (showRotate)
    {
        showRotate = false;
    }
    if (showScale)
    {
        showScale = false;
    }
}

void update_graph_connections()
{
    graph_mode_points.clear();
    for (auto &n1 : nodes)
    {
        for (auto &n2 : n1.connections)
        {
            drawline(n1.centerX, n1.centerY, n2->centerX, n2->centerY, graph_mode_points, 3);
        }
    }
    graph_points_length = graph_mode_points.size();
}

// Mouse button callback
void mouse_button_callback(GLFWwindow *window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT)
    {
        if (action == GLFW_PRESS)
        {
            cursorX_last_pressed = cursorX;
            cursorY_last_pressed = cursorY;
            isDrawing = true;
            isNewStroke = true;

            if (isSelecting)
            {
                lassoPoints.clear();
            }
            if (graph_mode)
            {
                Nodetype *e = find_closest_node_to(cursorX_last_pressed, cursorY_last_pressed, 30, nodes);
                if (e != NULL)
                {
                    temp_connected_nodes.push_back(e);
                }
            }
        }
        else if (action == GLFW_RELEASE)
        {
            isDrawing = false;

            if (isEmmitingmode)
            {
                for (int i = emmitbufferind; i < frames[currentFrame].size(); i++)
                {
                    emmitbuffer.push_back(i);
                }
                if (emmitbuffer.size() > 0)
                {
                    emitters.back().addstroke(emmitbuffer, currentFrame, frames, freeid);
                }
            }
            emmitbufferind = frames[currentFrame].size();

            if (isOscillatingmode)
            {
                for (int i = oscillatebfferind; i < frames[currentFrame].size(); i++)
                {
                    oscillatebuffer.push_back(i);
                }
                if (oscillatebuffer.size() > 0)
                {
                    oscillators.back().addstroke(oscillatebuffer, currentFrame, frames, freeid);
                }
            }
            oscillatebfferind = frames[currentFrame].size();

            if (istransforming)
            {
                istransforming = false;
                clear_transformations();
            }
            // Finalize selection
            if (isSelecting && !lassoPoints.empty())
            {
                clear_selection();
                for (int i = 0; i < frames[currentFrame].size(); ++i)
                {
                    if (isPointInPolygon(frames[currentFrame][i], lassoPoints))
                    {
                        selectedPointinds.push_back(i);
                    }
                }
            }
            if (graph_mode)
            {
                if (!graph_mode_points.empty())
                {
                    graph_mode_points.erase(graph_mode_points.begin() + graph_points_length, graph_mode_points.end());
                }
                Nodetype *e = find_closest_node_to(cursorX, cursorY, 30, nodes);
                if (e != NULL)
                {
                    temp_connected_nodes.push_back(e);
                }
                if (temp_connected_nodes.size() >= 2)
                {
                    Nodetype *e1 = temp_connected_nodes[0];
                    Nodetype *e2 = temp_connected_nodes[1];

                    if (e1->connected_to(e2))
                    {
                        e1->disconnect(e2);
                        e2->disconnect(e1);
                    }
                    else
                    {
                        e1->connect(e2);
                        e2->connect(e1);
                    }
                    update_graph_connections();
                }
                temp_connected_nodes.clear();
            }
        }
    }
}

int main()
{
    if (!glfwInit())
        return -1;

    GLFWwindow *window = glfwCreateWindow(1500, 1150, "Kitty emulation", nullptr, nullptr);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }
    init_frame();
    glfwMakeContextCurrent(window);
    glewInit();

    // Initialize ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 130");

    glOrtho(0.0, 1500, 0.0, 1150, -1.0, 1.0);
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetCursorPosCallback(window, cursor_position_callback);

    while (!glfwWindowShouldClose(window))
    {

        cursor_pos_speed_handler(window);
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        renderImGuiMenu();

        if (isPlaying)
        {
            updateAnimation();
        }

        render();

        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
